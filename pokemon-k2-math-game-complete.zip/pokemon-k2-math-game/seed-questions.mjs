import mysql from 'mysql2/promise';

const connection = await mysql.createConnection(process.env.DATABASE_URL);

// Clear existing questions
await connection.execute('DELETE FROM game_questions');

const questions = [];

// GYM 1: Number Ordering 1-20 (25 questions)
// Ascending sequences
questions.push(
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：1, 2, 3, ?, 5', opts: ['3', '4', '5', '6'], ans: '4', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：5, 6, 7, ?, 9', opts: ['7', '8', '9', '10'], ans: '8', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：10, 11, 12, ?, 14', opts: ['12', '13', '14', '15'], ans: '13', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：15, 16, 17, ?, 19', opts: ['17', '18', '19', '20'], ans: '18', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：2, 3, 4, ?, 6', opts: ['4', '5', '6', '7'], ans: '5', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：8, 9, 10, ?, 12', opts: ['10', '11', '12', '13'], ans: '11', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：12, 13, 14, ?, 16', opts: ['14', '15', '16', '17'], ans: '15', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：3, 4, 5, ?, 7', opts: ['5', '6', '7', '8'], ans: '6', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：7, 8, 9, ?, 11', opts: ['9', '10', '11', '12'], ans: '10', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：14, 15, 16, ?, 18', opts: ['16', '17', '18', '19'], ans: '17', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：1, 2, 3, ?, 5, 6', opts: ['3', '4', '5', '6'], ans: '4', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：6, 7, 8, ?, 10', opts: ['8', '9', '10', '11'], ans: '9', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：11, 12, 13, ?, 15', opts: ['13', '14', '15', '16'], ans: '14', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：16, 17, 18, ?, 20', opts: ['18', '19', '20', '21'], ans: '19', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：4, 5, 6, ?, 8', opts: ['6', '7', '8', '9'], ans: '7', diff: 1 },
);

// Descending sequences
questions.push(
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：20, 19, 18, ?, 16', opts: ['16', '17', '18', '19'], ans: '17', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：15, 14, 13, ?, 11', opts: ['10', '11', '12', '13'], ans: '12', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：10, 9, 8, ?, 6', opts: ['5', '6', '7', '8'], ans: '7', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：5, 4, 3, ?, 1', opts: ['1', '2', '3', '4'], ans: '2', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：18, 17, 16, ?, 14', opts: ['13', '14', '15', '16'], ans: '15', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：12, 11, 10, ?, 8', opts: ['7', '8', '9', '10'], ans: '9', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：8, 7, 6, ?, 4', opts: ['3', '4', '5', '6'], ans: '5', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：16, 15, 14, ?, 12', opts: ['11', '12', '13', '14'], ans: '13', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：11, 10, 9, ?, 7', opts: ['6', '7', '8', '9'], ans: '8', diff: 1 },
  { gym: 1, type: 'number_ordering', q: '請填入缺少的數字：6, 5, 4, ?, 2', opts: ['1', '2', '3', '4'], ans: '3', diff: 1 },
);

// GYM 2: Number Ordering 1-50 (25 questions)
questions.push(
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：1, 2, 3, ?, 5, 6, 7, 8, 9, 10', opts: ['3', '4', '5', '6'], ans: '4', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：10, 11, 12, ?, 14, 15, 16, 17, 18, 19, 20', opts: ['12', '13', '14', '15'], ans: '13', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：20, 21, 22, ?, 24, 25, 26, 27, 28, 29, 30', opts: ['22', '23', '24', '25'], ans: '23', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：30, 31, 32, ?, 34, 35, 36, 37, 38, 39, 40', opts: ['32', '33', '34', '35'], ans: '33', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：40, 41, 42, ?, 44, 45, 46, 47, 48, 49, 50', opts: ['42', '43', '44', '45'], ans: '43', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：5, 6, 7, ?, 9, 10, 11, 12, 13, 14, 15', opts: ['7', '8', '9', '10'], ans: '8', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：15, 16, 17, ?, 19, 20, 21, 22, 23, 24, 25', opts: ['17', '18', '19', '20'], ans: '18', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：25, 26, 27, ?, 29, 30, 31, 32, 33, 34, 35', opts: ['27', '28', '29', '30'], ans: '28', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：35, 36, 37, ?, 39, 40, 41, 42, 43, 44, 45', opts: ['37', '38', '39', '40'], ans: '38', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：45, 46, 47, ?, 49, 50', opts: ['47', '48', '49', '50'], ans: '48', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：50, 49, 48, ?, 46, 45, 44, 43, 42, 41, 40', opts: ['46', '47', '48', '49'], ans: '47', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：40, 39, 38, ?, 36, 35, 34, 33, 32, 31, 30', opts: ['36', '37', '38', '39'], ans: '37', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：30, 29, 28, ?, 26, 25, 24, 23, 22, 21, 20', opts: ['26', '27', '28', '29'], ans: '27', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：20, 19, 18, ?, 16, 15, 14, 13, 12, 11, 10', opts: ['16', '17', '18', '19'], ans: '17', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：10, 9, 8, ?, 6, 5, 4, 3, 2, 1', opts: ['6', '7', '8', '9'], ans: '7', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：2, 4, 6, ?, 10, 12, 14', opts: ['6', '8', '10', '12'], ans: '8', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：5, 10, 15, ?, 25, 30', opts: ['15', '20', '25', '30'], ans: '20', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：3, 6, 9, ?, 15, 18', opts: ['9', '12', '15', '18'], ans: '12', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：1, 3, 5, ?, 9, 11', opts: ['5', '7', '9', '11'], ans: '7', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：4, 8, 12, ?, 20, 24', opts: ['12', '16', '20', '24'], ans: '16', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：50, 45, 40, ?, 30, 25', opts: ['30', '35', '40', '45'], ans: '35', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：48, 46, 44, ?, 40, 38', opts: ['40', '42', '44', '46'], ans: '42', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：25, 30, 35, ?, 45, 50', opts: ['35', '40', '45', '50'], ans: '40', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：12, 24, 36, ?, 48', opts: ['36', '42', '48', '54'], ans: '48', diff: 2 },
  { gym: 2, type: 'number_ordering', q: '請填入缺少的數字：7, 14, 21, ?, 35', opts: ['21', '28', '35', '42'], ans: '28', diff: 2 },
);

// GYM 3: Number Ordering 1-100 (25 questions)
questions.push(
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：1, 2, 3, ?, 5, 6, 7, 8, 9, 10', opts: ['3', '4', '5', '6'], ans: '4', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：10, 20, 30, ?, 50, 60, 70, 80, 90, 100', opts: ['30', '40', '50', '60'], ans: '40', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：5, 10, 15, ?, 25, 30, 35, 40, 45, 50', opts: ['15', '20', '25', '30'], ans: '20', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：50, 51, 52, ?, 54, 55, 56, 57, 58, 59, 60', opts: ['52', '53', '54', '55'], ans: '53', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：60, 61, 62, ?, 64, 65, 66, 67, 68, 69, 70', opts: ['62', '63', '64', '65'], ans: '63', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：70, 71, 72, ?, 74, 75, 76, 77, 78, 79, 80', opts: ['72', '73', '74', '75'], ans: '73', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：80, 81, 82, ?, 84, 85, 86, 87, 88, 89, 90', opts: ['82', '83', '84', '85'], ans: '83', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：90, 91, 92, ?, 94, 95, 96, 97, 98, 99, 100', opts: ['92', '93', '94', '95'], ans: '93', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：100, 99, 98, ?, 96, 95, 94, 93, 92, 91, 90', opts: ['96', '97', '98', '99'], ans: '97', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：90, 89, 88, ?, 86, 85, 84, 83, 82, 81, 80', opts: ['86', '87', '88', '89'], ans: '87', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：80, 79, 78, ?, 76, 75, 74, 73, 72, 71, 70', opts: ['76', '77', '78', '79'], ans: '77', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：70, 69, 68, ?, 66, 65, 64, 63, 62, 61, 60', opts: ['66', '67', '68', '69'], ans: '67', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：60, 59, 58, ?, 56, 55, 54, 53, 52, 51, 50', opts: ['56', '57', '58', '59'], ans: '57', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：50, 49, 48, ?, 46, 45, 44, 43, 42, 41, 40', opts: ['46', '47', '48', '49'], ans: '47', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：40, 39, 38, ?, 36, 35, 34, 33, 32, 31, 30', opts: ['36', '37', '38', '39'], ans: '37', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：2, 4, 6, ?, 10, 12, 14, 16, 18, 20', opts: ['6', '8', '10', '12'], ans: '8', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：5, 10, 15, ?, 25, 30, 35, 40, 45, 50', opts: ['15', '20', '25', '30'], ans: '20', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：3, 6, 9, ?, 15, 18, 21, 24, 27, 30', opts: ['9', '12', '15', '18'], ans: '12', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：100, 90, 80, ?, 60, 50, 40, 30, 20, 10', opts: ['60', '70', '80', '90'], ans: '70', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：1, 11, 21, ?, 41, 51, 61, 71, 81, 91', opts: ['21', '31', '41', '51'], ans: '31', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：99, 88, 77, ?, 55, 44, 33, 22, 11', opts: ['55', '66', '77', '88'], ans: '66', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：15, 30, 45, ?, 75, 90', opts: ['45', '60', '75', '90'], ans: '60', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：20, 40, 60, ?, 100', opts: ['60', '80', '100', '120'], ans: '80', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：7, 14, 21, ?, 35, 42, 49, 56, 63, 70', opts: ['21', '28', '35', '42'], ans: '28', diff: 3 },
  { gym: 3, type: 'number_ordering', q: '請填入缺少的數字：9, 18, 27, ?, 45, 54, 63, 72, 81, 90', opts: ['27', '36', '45', '54'], ans: '36', diff: 3 },
);

// GYM 4: Single-digit Addition (12 questions)
questions.push(
  { gym: 4, type: 'addition', q: '3 + 4 = ?', opts: ['6', '7', '8', '9'], ans: '7', diff: 4 },
  { gym: 4, type: 'addition', q: '2 + 5 = ?', opts: ['6', '7', '8', '9'], ans: '7', diff: 4 },
  { gym: 4, type: 'addition', q: '1 + 8 = ?', opts: ['7', '8', '9', '10'], ans: '9', diff: 4 },
  { gym: 4, type: 'addition', q: '4 + 3 = ?', opts: ['6', '7', '8', '9'], ans: '7', diff: 4 },
  { gym: 4, type: 'addition', q: '5 + 2 = ?', opts: ['6', '7', '8', '9'], ans: '7', diff: 4 },
  { gym: 4, type: 'addition', q: '6 + 2 = ?', opts: ['7', '8', '9', '10'], ans: '8', diff: 4 },
  { gym: 4, type: 'addition', q: '3 + 5 = ?', opts: ['7', '8', '9', '10'], ans: '8', diff: 4 },
  { gym: 4, type: 'addition', q: '2 + 7 = ?', opts: ['8', '9', '10', '11'], ans: '9', diff: 4 },
  { gym: 4, type: 'addition', q: '4 + 4 = ?', opts: ['7', '8', '9', '10'], ans: '8', diff: 4 },
  { gym: 4, type: 'addition', q: '1 + 6 = ?', opts: ['6', '7', '8', '9'], ans: '7', diff: 4 },
  { gym: 4, type: 'addition', q: '5 + 3 = ?', opts: ['7', '8', '9', '10'], ans: '8', diff: 4 },
  { gym: 4, type: 'addition', q: '2 + 6 = ?', opts: ['7', '8', '9', '10'], ans: '8', diff: 4 },
);

// GYM 5: Single-digit Subtraction (13 questions)
questions.push(
  { gym: 5, type: 'subtraction', q: '9 - 5 = ?', opts: ['3', '4', '5', '6'], ans: '4', diff: 5 },
  { gym: 5, type: 'subtraction', q: '8 - 3 = ?', opts: ['4', '5', '6', '7'], ans: '5', diff: 5 },
  { gym: 5, type: 'subtraction', q: '7 - 2 = ?', opts: ['4', '5', '6', '7'], ans: '5', diff: 5 },
  { gym: 5, type: 'subtraction', q: '6 - 4 = ?', opts: ['1', '2', '3', '4'], ans: '2', diff: 5 },
  { gym: 5, type: 'subtraction', q: '9 - 4 = ?', opts: ['4', '5', '6', '7'], ans: '5', diff: 5 },
  { gym: 5, type: 'subtraction', q: '8 - 2 = ?', opts: ['5', '6', '7', '8'], ans: '6', diff: 5 },
  { gym: 5, type: 'subtraction', q: '7 - 3 = ?', opts: ['3', '4', '5', '6'], ans: '4', diff: 5 },
  { gym: 5, type: 'subtraction', q: '10 - 5 = ?', opts: ['4', '5', '6', '7'], ans: '5', diff: 5 },
  { gym: 5, type: 'subtraction', q: '6 - 2 = ?', opts: ['3', '4', '5', '6'], ans: '4', diff: 5 },
  { gym: 5, type: 'subtraction', q: '9 - 3 = ?', opts: ['5', '6', '7', '8'], ans: '6', diff: 5 },
  { gym: 5, type: 'subtraction', q: '8 - 4 = ?', opts: ['3', '4', '5', '6'], ans: '4', diff: 5 },
  { gym: 5, type: 'subtraction', q: '7 - 1 = ?', opts: ['5', '6', '7', '8'], ans: '6', diff: 5 },
  { gym: 5, type: 'subtraction', q: '10 - 3 = ?', opts: ['6', '7', '8', '9'], ans: '7', diff: 5 },
);

// Insert questions into database
for (const q of questions) {
  await connection.execute(
    'INSERT INTO game_questions (gymId, questionType, question, options, correctAnswer, difficulty) VALUES (?, ?, ?, ?, ?, ?)',
    [
      q.gym,
      q.type,
      q.q,
      JSON.stringify(q.opts),
      q.ans,
      q.diff,
    ]
  );
}

console.log(`✅ Successfully seeded ${questions.length} questions into the database!`);
await connection.end();

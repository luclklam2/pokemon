# Pokémon K2 Math Challenge - 完整程式碼文檔

## 目錄

1. [後端 API (tRPC)](#後端-api-trpc)
2. [前端遊戲組件](#前端遊戲組件)
3. [音效系統](#音效系統)
4. [樣式和設計](#樣式和設計)
5. [資料庫架構](#資料庫架構)

---

## 後端 API (tRPC)

### server/routers.ts - 遊戲 API 程序

```typescript
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  createGameSession,
  getCurrentQuestion,
  getSessionSummary,
  submitAnswer,
  getPlayerProgress,
  selectPlayerPokemon,
  getPlayerPokemon,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  game: router({
    // Get player's progress across all gyms
    getProgress: protectedProcedure.query(async ({ ctx }) => {
      return await getPlayerProgress(ctx.user.id);
    }),

    // Start a new game session for a specific gym
    startSession: protectedProcedure
      .input(z.object({ gymId: z.number().min(1).max(5) }))
      .mutation(async ({ ctx, input }) => {
        const session = await createGameSession(ctx.user.id, input.gymId);
        return {
          sessionId: session.id,
          gymId: session.gymId,
          playerHP: session.playerHP,
          opponentHP: session.opponentHP,
        };
      }),

    // Get current question in a session
    getCurrentQuestion: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await getCurrentQuestion(input.sessionId);
      }),

    // Get session summary (progress, HP, badges)
    getSessionSummary: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await getSessionSummary(input.sessionId);
      }),

    // Submit answer and update game state
    submitAnswer: protectedProcedure
      .input(
        z.object({
          sessionId: z.number(),
          questionId: z.number(),
          answer: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await submitAnswer(ctx.user.id, input);
      }),

    // Select player's Pokémon
    selectPokemon: protectedProcedure
      .input(z.object({ pokemonName: z.string(), pokemonEmoji: z.string() }))
      .mutation(async ({ ctx, input }) => {
        return await selectPlayerPokemon(ctx.user.id, input);
      }),

    // Get player's selected Pokémon
    getPlayerPokemon: protectedProcedure.query(async ({ ctx }) => {
      return await getPlayerPokemon(ctx.user.id);
    }),
  }),
});

export type AppRouter = typeof appRouter;
```

### server/db.ts - 資料庫查詢函數

```typescript
import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  users,
  game_questions,
  user_progress,
  game_sessions,
  answer_history,
  player_pokemon,
  gym_leader_pokemon,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// Get player's progress
export async function getPlayerProgress(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(user_progress)
    .where(eq(user_progress.userId, userId));
}

// Create a new game session
export async function createGameSession(userId: number, gymId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(game_sessions).values({
    userId,
    gymId,
    playerHP: 100,
    opponentHP: [80, 100, 100, 100, 120][gymId - 1] || 100,
    answeredCount: 0,
    correctCount: 0,
    status: "active",
  });

  const sessionId = (result as any).insertId;
  const session = await db
    .select()
    .from(game_sessions)
    .where(eq(game_sessions.id, sessionId))
    .limit(1);

  return session[0];
}

// Get current question in a session
export async function getCurrentQuestion(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const session = await db
    .select()
    .from(game_sessions)
    .where(eq(game_sessions.id, sessionId))
    .limit(1);

  if (!session.length) throw new Error("Session not found");

  const currentSession = session[0];
  const questions = await db
    .select()
    .from(game_questions)
    .where(eq(game_questions.gymId, currentSession.gymId));

  if (!questions.length) throw new Error("No questions found");

  // Get the next unanswered question
  const answeredQuestions = await db
    .select()
    .from(answer_history)
    .where(eq(answer_history.sessionId, sessionId));

  const answeredIds = new Set(answeredQuestions.map(a => a.questionId));
  const unansweredQuestion = questions.find(q => !answeredIds.has(q.id));

  if (!unansweredQuestion) {
    throw new Error("All questions answered");
  }

  return unansweredQuestion;
}

// Get session summary
export async function getSessionSummary(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const session = await db
    .select()
    .from(game_sessions)
    .where(eq(game_sessions.id, sessionId))
    .limit(1);

  if (!session.length) throw new Error("Session not found");

  const currentSession = session[0];
  const totalQuestions = await db
    .select()
    .from(game_questions)
    .where(eq(game_questions.gymId, currentSession.gymId));

  const progress = await db
    .select()
    .from(user_progress)
    .where(
      and(
        eq(user_progress.userId, currentSession.userId),
        eq(user_progress.gymId, currentSession.gymId)
      )
    )
    .limit(1);

  return {
    sessionId,
    gymId: currentSession.gymId,
    playerHP: currentSession.playerHP,
    opponentHP: currentSession.opponentHP,
    answeredCount: currentSession.answeredCount,
    correctCount: currentSession.correctCount,
    totalQuestions: totalQuestions.length,
    badgesEarned: progress.length > 0 ? progress[0].badgesEarned : 0,
    status: currentSession.status,
  };
}

// Submit answer
export async function submitAnswer(
  userId: number,
  input: { sessionId: number; questionId: number; answer: string }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const session = await db
    .select()
    .from(game_sessions)
    .where(eq(game_sessions.id, input.sessionId))
    .limit(1);

  if (!session.length) throw new Error("Session not found");

  const question = await db
    .select()
    .from(game_questions)
    .where(eq(game_questions.id, input.questionId))
    .limit(1);

  if (!question.length) throw new Error("Question not found");

  const isCorrect = input.answer === question[0].correctAnswer;

  // Record answer
  await db.insert(answer_history).values({
    sessionId: input.sessionId,
    questionId: input.questionId,
    userAnswer: input.answer,
    isCorrect,
  });

  // Update session
  let newPlayerHP = session[0].playerHP;
  let newOpponentHP = session[0].opponentHP;
  let newCorrectCount = session[0].correctCount;

  if (isCorrect) {
    newOpponentHP = Math.max(0, newOpponentHP - 20);
    newCorrectCount++;
  } else {
    newPlayerHP = Math.max(0, newPlayerHP - 20);
  }

  const newAnsweredCount = session[0].answeredCount + 1;

  // Determine session status
  let sessionStatus = "active";
  if (newOpponentHP === 0) {
    sessionStatus = "completed";
  } else if (newPlayerHP === 0) {
    sessionStatus = "failed";
  }

  await db
    .update(game_sessions)
    .set({
      playerHP: newPlayerHP,
      opponentHP: newOpponentHP,
      correctCount: newCorrectCount,
      answeredCount: newAnsweredCount,
      status: sessionStatus,
    })
    .where(eq(game_sessions.id, input.sessionId));

  // If completed, update progress
  if (sessionStatus === "completed") {
    const existingProgress = await db
      .select()
      .from(user_progress)
      .where(
        and(
          eq(user_progress.userId, userId),
          eq(user_progress.gymId, session[0].gymId)
        )
      )
      .limit(1);

    if (existingProgress.length === 0) {
      await db.insert(user_progress).values({
        userId,
        gymId: session[0].gymId,
        badgesEarned: 1,
        completedAt: new Date(),
      });
    }
  }

  return {
    isCorrect,
    sessionStatus,
  };
}

// Select player Pokémon
export async function selectPlayerPokemon(
  userId: number,
  input: { pokemonName: string; pokemonEmoji: string }
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Delete existing selection
  await db.delete(player_pokemon).where(eq(player_pokemon.userId, userId));

  // Insert new selection
  await db.insert(player_pokemon).values({
    userId,
    pokemonName: input.pokemonName,
    pokemonEmoji: input.pokemonEmoji,
  });

  return { success: true };
}

// Get player's Pokémon
export async function getPlayerPokemon(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(player_pokemon)
    .where(eq(player_pokemon.userId, userId))
    .limit(1);

  if (result.length === 0) {
    // Return default Pokémon
    return {
      pokemonName: "Pikachu",
      pokemonEmoji: "⚡",
    };
  }

  return result[0];
}
```

---

## 前端遊戲組件

### client/src/pages/Game.tsx - 主遊戲頁面

```typescript
import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import PokemonSelection from '@/components/game/PokemonSelection';
import GymSelection from '@/components/game/GymSelection';
import GamePlay from '@/components/game/GamePlay';
import BadgeReward from '@/components/game/BadgeReward';
import GameOver from '@/components/game/GameOver';
import AllGymsComplete from '@/components/game/AllGymsComplete';
import { trpc } from '@/lib/trpc';
import '../styles/pixel-art.css';

type GameState = 'selectPokemon' | 'selectGym' | 'playing' | 'badgeReward' | 'gameOver' | 'allComplete';

export default function Game() {
  const { user } = useAuth();
  const [gameState, setGameState] = useState<GameState>('selectPokemon');
  const [selectedPokemon, setSelectedPokemon] = useState<{ name: string; emoji: string } | null>(null);
  const [selectedGym, setSelectedGym] = useState<number | null>(null);
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [completedGyms, setCompletedGyms] = useState<number[]>([]);

  const progressQuery = trpc.game.getProgress.useQuery();
  const startSessionMutation = trpc.game.startSession.useMutation();
  const selectPokemonMutation = trpc.game.selectPokemon.useMutation();

  const handlePokemonSelect = async (pokemon: { name: string; emoji: string }) => {
    setSelectedPokemon(pokemon);
    await selectPokemonMutation.mutateAsync(pokemon);
    setGameState('selectGym');
  };

  const handleGymSelect = async (gymId: number) => {
    setSelectedGym(gymId);
    const session = await startSessionMutation.mutateAsync({ gymId });
    setSessionId(session.sessionId);
    setGameState('playing');
  };

  const handleGameComplete = (status: 'completed' | 'failed') => {
    if (status === 'completed') {
      if (selectedGym) {
        setCompletedGyms([...completedGyms, selectedGym]);
        if (completedGyms.length === 4) {
          setGameState('allComplete');
        } else {
          setGameState('badgeReward');
        }
      }
    } else {
      setGameState('gameOver');
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen pixel-bg-sky">
      {gameState === 'selectPokemon' && (
        <PokemonSelection onSelect={handlePokemonSelect} />
      )}
      {gameState === 'selectGym' && (
        <GymSelection
          completedGyms={completedGyms}
          onSelectGym={handleGymSelect}
        />
      )}
      {gameState === 'playing' && sessionId && (
        <GamePlay
          sessionId={sessionId}
          gymId={selectedGym || 1}
          onGameComplete={handleGameComplete}
        />
      )}
      {gameState === 'badgeReward' && (
        <BadgeReward
          gymId={selectedGym || 1}
          onContinue={() => setGameState('selectGym')}
        />
      )}
      {gameState === 'gameOver' && (
        <GameOver
          onRetry={() => {
            if (selectedGym) {
              handleGymSelect(selectedGym);
            }
          }}
          onQuit={() => setGameState('selectGym')}
        />
      )}
      {gameState === 'allComplete' && (
        <AllGymsComplete onQuit={() => setGameState('selectGym')} />
      )}
    </div>
  );
}
```

### client/src/components/game/PokemonSelection.tsx - 寶可夢選擇

```typescript
import { Button } from '@/components/ui/button';
import '../../styles/pixel-art.css';

interface PokemonSelectionProps {
  onSelect: (pokemon: { name: string; emoji: string }) => void;
}

const AVAILABLE_POKEMON = [
  { name: 'Pikachu', emoji: '⚡' },
  { name: 'Charmander', emoji: '🔥' },
  { name: 'Squirtle', emoji: '💧' },
  { name: 'Bulbasaur', emoji: '🌿' },
  { name: 'Ditto', emoji: '👾' },
];

export default function PokemonSelection({ onSelect }: PokemonSelectionProps) {
  return (
    <div className="min-h-screen pixel-bg-sky flex flex-col items-center justify-center p-4">
      <div className="text-center mb-12">
        <h1 className="pixel-font text-5xl text-yellow-400 mb-4" style={{ textShadow: '2px 2px 0px black' }}>
          選擇你的夥伴
        </h1>
        <p className="pixel-font text-white text-lg">選擇一隻寶可夢開始冒險！</p>
      </div>

      <div className="grid grid-cols-2 gap-6 mb-8">
        {AVAILABLE_POKEMON.map((pokemon) => (
          <button
            key={pokemon.name}
            onClick={() => onSelect(pokemon)}
            className="pixel-card bg-white p-6 hover:bg-yellow-100 transition-all transform hover:scale-110"
          >
            <div className="text-6xl mb-2">{pokemon.emoji}</div>
            <p className="pixel-font font-bold text-gray-800">{pokemon.name}</p>
          </button>
        ))}
      </div>
    </div>
  );
}
```

### client/src/components/game/GamePlay.tsx - 遊戲進行中

```typescript
import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import BattleScene from './BattleScene';
import { audioManager } from '@/lib/audioManager';
import SoundControl from './SoundControl';
import '../../styles/pixel-art.css';

interface GamePlayProps {
  sessionId: number;
  gymId: number;
  onGameComplete: (status: 'completed' | 'failed') => void;
}

interface PokemonData {
  name: string;
  emoji: string;
  hp: number;
  maxHP: number;
}

interface OpponentPokemonData extends PokemonData {
  leaderName: string;
}

export default function GamePlay({ sessionId, gymId, onGameComplete }: GamePlayProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswering, setIsAnswering] = useState(false);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [playerPokemon, setPlayerPokemon] = useState<PokemonData | null>(null);
  const [opponentPokemon, setOpponentPokemon] = useState<OpponentPokemonData | null>(null);
  const [sessionData, setSessionData] = useState<any>(null);
  const [isAttacking, setIsAttacking] = useState(false);
  const [attackType, setAttackType] = useState<'player' | 'opponent' | undefined>(undefined);

  const playerPokemonQuery = trpc.game.getPlayerPokemon.useQuery();
  const currentQuestionQuery = trpc.game.getCurrentQuestion.useQuery(
    { sessionId },
    { refetchInterval: false }
  );
  const sessionSummaryQuery = trpc.game.getSessionSummary.useQuery(
    { sessionId },
    { refetchInterval: 2000 }
  );

  const submitAnswerMutation = trpc.game.submitAnswer.useMutation({
    onSuccess: (data) => {
      if (data.isCorrect) {
        audioManager.playCorrectAnswer();
        audioManager.playAttack();
      } else {
        audioManager.playWrongAnswer();
      }

      setIsAttacking(true);
      setAttackType(data.isCorrect ? 'player' : 'opponent');

      setFeedback({
        isCorrect: data.isCorrect,
        message: data.isCorrect ? '答對了！寶可夢出招！🎉' : '答錯了！受到傷害！',
      });

      setTimeout(() => {
        setIsAttacking(false);
        setAttackType(undefined);

        if (data.sessionStatus === 'completed') {
          audioManager.playBadgeEarned();
          onGameComplete('completed');
        } else if (data.sessionStatus === 'failed') {
          audioManager.playGameOver();
          onGameComplete('failed');
        } else {
          setSelectedAnswer(null);
          setFeedback(null);
          currentQuestionQuery.refetch();
        }
      }, 1500);
    },
  });

  useEffect(() => {
    if (sessionSummaryQuery.data) {
      setSessionData(sessionSummaryQuery.data);
    }
  }, [sessionSummaryQuery.data]);

  useEffect(() => {
    if (playerPokemonQuery.data && sessionData) {
      setPlayerPokemon({
        name: playerPokemonQuery.data.pokemonName,
        emoji: playerPokemonQuery.data.pokemonEmoji,
        hp: sessionData.playerHP,
        maxHP: 100,
      });
    }
  }, [playerPokemonQuery.data, sessionData]);

  useEffect(() => {
    if (currentQuestionQuery.data && sessionData && !opponentPokemon) {
      const opponents: Record<number, any> = {
        1: { name: 'Pikachu', emoji: '⚡', leaderName: '小智', maxHP: 80 },
        2: { name: 'Charizard', emoji: '🔥', leaderName: '火焰館主', maxHP: 100 },
        3: { name: 'Blastoise', emoji: '💧', leaderName: '水之館主', maxHP: 100 },
        4: { name: 'Venusaur', emoji: '🌿', leaderName: '草之館主', maxHP: 100 },
        5: { name: 'Dragonite', emoji: '🐉', leaderName: '龍之館主', maxHP: 120 },
      };
      const opponent = opponents[gymId] || opponents[1];
      setOpponentPokemon({
        ...opponent,
        hp: sessionData.opponentHP,
      });
      audioManager.playGymEntry();
    }
  }, [currentQuestionQuery.data, sessionData, gymId, opponentPokemon]);

  useEffect(() => {
    audioManager.playBackgroundMusic();
    return () => {};
  }, []);

  const handleSubmitAnswer = () => {
    if (!selectedAnswer || !currentQuestionQuery.data) return;
    audioManager.playTone(523, 0.15);
    setIsAnswering(true);
    submitAnswerMutation.mutate({
      sessionId,
      questionId: currentQuestionQuery.data.id,
      answer: selectedAnswer,
    });
  };

  if (!currentQuestionQuery.data || !playerPokemon || !opponentPokemon || !sessionData) {
    return (
      <div className="min-h-screen pixel-bg-sky flex items-center justify-center">
        <div className="pixel-card bg-white text-center">
          <p className="text-xl font-bold text-gray-800">載入中...</p>
        </div>
      </div>
    );
  }

  const question = currentQuestionQuery.data;
  const currentQuestionNum = sessionData.answeredCount + 1;
  const totalQuestions = sessionData.totalQuestions;

  return (
    <div className="min-h-screen pixel-bg-sky flex flex-col p-4 relative">
      <SoundControl />

      <div className="flex justify-between items-center mb-4">
        <div className="pixel-card bg-yellow-300 px-4 py-2">
          <p className="pixel-font text-sm font-bold">
            第 {currentQuestionNum} / {totalQuestions} 題
          </p>
        </div>
        <div className="pixel-card bg-green-300 px-4 py-2">
          <p className="pixel-font text-sm font-bold">
            徽章: {sessionData.badgesEarned}
          </p>
        </div>
      </div>

      {playerPokemon && opponentPokemon && (
        <BattleScene
          playerPokemon={playerPokemon}
          opponentPokemon={opponentPokemon}
          isAttacking={isAttacking}
          attackType={attackType}
        />
      )}

      <div className="pixel-card bg-white mt-6 mb-4">
        <h2 className="pixel-font text-lg font-bold text-center mb-4 text-gray-800">
          {question.question}
        </h2>

        <div className="grid grid-cols-2 gap-3 mb-4">
          {question.options.map((option: string, index: number) => (
            <button
              key={index}
              onClick={() => setSelectedAnswer(option)}
              disabled={isAnswering}
              className={`pixel-button text-sm font-bold transition-all ${
                selectedAnswer === option
                  ? 'bg-yellow-300 scale-105'
                  : 'bg-blue-300 hover:bg-blue-400'
              } ${isAnswering ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {option}
            </button>
          ))}
        </div>

        {feedback && (
          <div
            className={`pixel-card text-center py-2 mb-4 ${
              feedback.isCorrect ? 'bg-green-300' : 'bg-red-300'
            }`}
          >
            <p className="pixel-font font-bold text-gray-800">
              {feedback.message}
            </p>
          </div>
        )}

        <button
          onClick={handleSubmitAnswer}
          disabled={!selectedAnswer || isAnswering}
          className="w-full pixel-button text-lg font-bold bg-red-500 text-white disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isAnswering ? '提交中...' : '提交答案'}
        </button>
      </div>
    </div>
  );
}
```

### client/src/components/game/BattleScene.tsx - 戰鬥場景

```typescript
import { useState, useEffect } from 'react';
import HPBar from './HPBar';
import '../../styles/pixel-art.css';

interface BattleSceneProps {
  playerPokemon: {
    name: string;
    emoji: string;
    hp: number;
    maxHP: number;
  };
  opponentPokemon: {
    name: string;
    emoji: string;
    hp: number;
    maxHP: number;
    leaderName: string;
  };
  isAttacking?: boolean;
  attackType?: 'player' | 'opponent';
}

export default function BattleScene({
  playerPokemon,
  opponentPokemon,
  isAttacking = false,
  attackType,
}: BattleSceneProps) {
  const [showAttackEffect, setShowAttackEffect] = useState(false);

  useEffect(() => {
    if (isAttacking) {
      setShowAttackEffect(true);
      const timer = setTimeout(() => setShowAttackEffect(false), 500);
      return () => clearTimeout(timer);
    }
  }, [isAttacking]);

  return (
    <div className="w-full pixel-card bg-blue-300 mb-8 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
        backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(0,0,0,.05) 35px, rgba(0,0,0,.05) 70px)'
      }}></div>

      <div className="relative z-10 p-8">
        {/* Opponent Pokémon */}
        <div className="mb-12">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="pixel-font text-xs text-gray-800">{opponentPokemon.leaderName}</p>
              <p className="pixel-font text-lg font-bold text-gray-800">{opponentPokemon.name}</p>
            </div>
            <div className="text-right">
              <p className="pixel-font text-xs text-gray-800">HP</p>
              <p className="pixel-font text-lg font-bold text-gray-800">
                {opponentPokemon.hp} / {opponentPokemon.maxHP}
              </p>
            </div>
          </div>
          <HPBar
            currentHP={opponentPokemon.hp}
            maxHP={opponentPokemon.maxHP}
            isOpponent={true}
          />
        </div>

        {/* VS and Attack Effect */}
        <div className="flex justify-center items-center mb-12 relative h-20">
          {showAttackEffect && attackType === 'player' && (
            <div className="absolute left-1/4 text-4xl animate-pulse">⚡</div>
          )}
          {showAttackEffect && attackType === 'opponent' && (
            <div className="absolute right-1/4 text-4xl animate-pulse">⚡</div>
          )}
          <div className="pixel-card bg-white px-4 py-2">
            <p className="pixel-font font-bold text-gray-800">VS</p>
          </div>
        </div>

        {/* Player Pokémon */}
        <div>
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="pixel-font text-xs text-gray-800">你的寶可夢</p>
              <p className="pixel-font text-lg font-bold text-gray-800">{playerPokemon.name}</p>
            </div>
            <div className="text-right">
              <p className="pixel-font text-xs text-gray-800">HP</p>
              <p className="pixel-font text-lg font-bold text-gray-800">
                {playerPokemon.hp} / {playerPokemon.maxHP}
              </p>
            </div>
          </div>
          <HPBar
            currentHP={playerPokemon.hp}
            maxHP={playerPokemon.maxHP}
            isOpponent={false}
          />
        </div>
      </div>
    </div>
  );
}
```

---

## 音效系統

### client/src/lib/audioManager.ts - 8-bit 音效生成器

```typescript
class AudioManager {
  private audioContext: AudioContext | null = null;
  private isMuted = false;
  private volume = 0.3;

  private initAudioContext() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  playTone(frequency: number, duration: number) {
    if (this.isMuted) return;

    this.initAudioContext();
    if (!this.audioContext) return;

    const now = this.audioContext.currentTime;
    const osc = this.audioContext.createOscillator();
    const gain = this.audioContext.createGain();

    osc.connect(gain);
    gain.connect(this.audioContext.destination);

    osc.frequency.value = frequency;
    osc.type = 'square';

    gain.gain.setValueAtTime(this.volume, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + duration);

    osc.start(now);
    osc.stop(now + duration);
  }

  playMelody(notes: Array<{ freq: number; duration: number }>) {
    if (this.isMuted) return;

    this.initAudioContext();
    if (!this.audioContext) return;

    let currentTime = this.audioContext.currentTime;

    notes.forEach(({ freq, duration }) => {
      const osc = this.audioContext!.createOscillator();
      const gain = this.audioContext!.createGain();

      osc.connect(gain);
      gain.connect(this.audioContext!.destination);

      osc.frequency.value = freq;
      osc.type = 'square';

      gain.gain.setValueAtTime(this.volume, currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, currentTime + duration);

      osc.start(currentTime);
      osc.stop(currentTime + duration);

      currentTime += duration;
    });
  }

  playCorrectAnswer() {
    this.playMelody([
      { freq: 523, duration: 0.1 }, // C5
      { freq: 659, duration: 0.1 }, // E5
      { freq: 784, duration: 0.2 }, // G5
    ]);
  }

  playWrongAnswer() {
    this.playMelody([
      { freq: 349, duration: 0.15 }, // F4
      { freq: 293, duration: 0.15 }, // D4
      { freq: 246, duration: 0.3 }, // B3
    ]);
  }

  playAttack() {
    this.playMelody([
      { freq: 800, duration: 0.05 },
      { freq: 600, duration: 0.05 },
      { freq: 400, duration: 0.1 },
    ]);
  }

  playBadgeEarned() {
    this.playMelody([
      { freq: 523, duration: 0.1 },
      { freq: 659, duration: 0.1 },
      { freq: 784, duration: 0.1 },
      { freq: 1047, duration: 0.3 },
    ]);
  }

  playGameOver() {
    this.playMelody([
      { freq: 392, duration: 0.2 },
      { freq: 349, duration: 0.2 },
      { freq: 293, duration: 0.4 },
    ]);
  }

  playGymEntry() {
    this.playMelody([
      { freq: 659, duration: 0.1 },
      { freq: 784, duration: 0.1 },
      { freq: 880, duration: 0.2 },
    ]);
  }

  playBackgroundMusic() {
    if (this.isMuted) return;

    // Simple Pokémon-style background music loop
    const melody = [
      { freq: 523, duration: 0.2 },
      { freq: 659, duration: 0.2 },
      { freq: 784, duration: 0.2 },
      { freq: 659, duration: 0.2 },
      { freq: 523, duration: 0.4 },
    ];

    const playLoop = () => {
      this.playMelody(melody);
      setTimeout(playLoop, 2000);
    };

    playLoop();
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
  }
}

export const audioManager = new AudioManager();
```

---

## 樣式和設計

### client/src/styles/pixel-art.css - Pokémon 像素藝術風格

```css
@import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap');

/* Pixel Art Background */
.pixel-bg-sky {
  background: linear-gradient(180deg, #87CEEB 0%, #E0F6FF 100%);
  position: relative;
}

.pixel-bg-sky::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-image:
    radial-gradient(circle at 20% 30%, rgba(255, 255, 255, 0.3) 0%, transparent 50%),
    radial-gradient(circle at 80% 70%, rgba(255, 255, 255, 0.2) 0%, transparent 50%);
  pointer-events: none;
}

/* Pixel Font */
.pixel-font {
  font-family: 'Press Start 2P', cursive;
  letter-spacing: 2px;
}

.pixel-text-shadow {
  text-shadow: 2px 2px 0px rgba(0, 0, 0, 0.5);
}

/* Pixel Card */
.pixel-card {
  border: 3px solid #000;
  box-shadow: 4px 4px 0px rgba(0, 0, 0, 0.3);
  background-color: #fff;
}

.pixel-card.bg-white {
  background-color: #fff;
}

.pixel-card.bg-red-300 {
  background-color: #ff6b6b;
}

.pixel-card.bg-green-300 {
  background-color: #51cf66;
}

.pixel-card.bg-yellow-300 {
  background-color: #ffd43b;
}

.pixel-card.bg-blue-300 {
  background-color: #74c0fc;
}

/* Pixel Button */
.pixel-button {
  font-family: 'Press Start 2P', cursive;
  border: 3px solid #000;
  background-color: #FF0000;
  color: #fff;
  padding: 12px 24px;
  cursor: pointer;
  box-shadow: 4px 4px 0px rgba(0, 0, 0, 0.3);
  transition: all 0.1s;
  font-size: 14px;
  letter-spacing: 1px;
}

.pixel-button:hover:not(:disabled) {
  transform: translate(-2px, -2px);
  box-shadow: 6px 6px 0px rgba(0, 0, 0, 0.3);
}

.pixel-button:active:not(:disabled) {
  transform: translate(2px, 2px);
  box-shadow: 2px 2px 0px rgba(0, 0, 0, 0.3);
}

.pixel-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* HP Bar */
.hp-bar {
  width: 100%;
  height: 24px;
  background-color: #000;
  border: 2px solid #000;
  position: relative;
  overflow: hidden;
}

.hp-bar-fill {
  height: 100%;
  background: linear-gradient(90deg, #00ff00 0%, #ffff00 50%, #ff0000 100%);
  transition: width 0.3s ease-out;
  border-right: 2px solid #000;
}

/* Animations */
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.animate-pulse {
  animation: pulse 0.5s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-5px); }
  75% { transform: translateX(5px); }
}

.animate-shake {
  animation: shake 0.3s;
}

/* Pixel Art Borders */
.pixel-border {
  border: 3px solid #000;
  box-shadow: inset -3px -3px 0px rgba(0, 0, 0, 0.2);
}

/* Responsive */
@media (max-width: 640px) {
  .pixel-font {
    font-size: 12px;
    letter-spacing: 1px;
  }

  .pixel-button {
    padding: 8px 16px;
    font-size: 12px;
  }
}
```

---

## 資料庫架構

### drizzle/schema.ts - 資料庫表結構

```typescript
import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
} from "drizzle-orm/mysql-core";

// Users table
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

// Game questions table
export const game_questions = mysqlTable("game_questions", {
  id: int("id").autoincrement().primaryKey(),
  gymId: int("gymId").notNull(),
  question: text("question").notNull(),
  options: text("options").notNull(), // JSON array
  correctAnswer: varchar("correctAnswer", { length: 255 }).notNull(),
  difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard"]).default("easy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// User progress table
export const user_progress = mysqlTable("user_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gymId: int("gymId").notNull(),
  badgesEarned: int("badgesEarned").default(0),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Game sessions table
export const game_sessions = mysqlTable("game_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gymId: int("gymId").notNull(),
  playerHP: int("playerHP").default(100),
  opponentHP: int("opponentHP").default(100),
  answeredCount: int("answeredCount").default(0),
  correctCount: int("correctCount").default(0),
  status: mysqlEnum("status", ["active", "completed", "failed"]).default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Answer history table
export const answer_history = mysqlTable("answer_history", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  questionId: int("questionId").notNull(),
  userAnswer: varchar("userAnswer", { length: 255 }).notNull(),
  isCorrect: boolean("isCorrect").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Player Pokémon table
export const player_pokemon = mysqlTable("player_pokemon", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  pokemonName: varchar("pokemonName", { length: 100 }).notNull(),
  pokemonEmoji: varchar("pokemonEmoji", { length: 10 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Gym leader Pokémon table
export const gym_leader_pokemon = mysqlTable("gym_leader_pokemon", {
  id: int("id").autoincrement().primaryKey(),
  gymId: int("gymId").notNull().unique(),
  pokemonName: varchar("pokemonName", { length: 100 }).notNull(),
  pokemonEmoji: varchar("pokemonEmoji", { length: 10 }).notNull(),
  leaderName: varchar("leaderName", { length: 100 }).notNull(),
  baseHP: int("baseHP").default(100),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// Type exports
export type User = typeof users.$inferSelect;
export type GameQuestion = typeof game_questions.$inferSelect;
export type UserProgress = typeof user_progress.$inferSelect;
export type GameSession = typeof game_sessions.$inferSelect;
export type AnswerHistory = typeof answer_history.$inferSelect;
export type PlayerPokemon = typeof player_pokemon.$inferSelect;
export type GymLeaderPokemon = typeof gym_leader_pokemon.$inferSelect;
```

---

## 完整功能總結

✅ **100 道數學題** - 分佈在 5 個道館
✅ **寶可夢選擇系統** - 5 隻初始寶可夢
✅ **戰鬥機制** - 答對攻擊對手，答錯受傷
✅ **HP 系統** - 雙方 HP 條動畫
✅ **8-bit 音效** - 答對/答錯/攻擊/徽章音效
✅ **登入系統** - 玩家名稱和進度保存
✅ **像素藝術風格** - 正宗 Pokémon 復古設計
✅ **免責聲明** - 版權和歸屬信息
✅ **響應式設計** - 支援行動設備
✅ **進度追蹤** - 徽章和完成狀態

---

## 部署和運行

### 開發環境
```bash
cd /home/ubuntu/pokemon-k2-math-game
pnpm install
pnpm dev
```

### 生產環境
```bash
pnpm build
pnpm start
```

### 測試
```bash
pnpm test
```

---

**遊戲已準備好供使用！**

/**
 * 8-bit Pokémon-style audio effects generator
 * Uses Web Audio API to generate retro sound effects
 */

class AudioManager {
  private audioContext: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isMuted = false;

  constructor() {
    this.initAudioContext();
  }

  private initAudioContext() {
    if (typeof window !== 'undefined' && !this.audioContext) {
      try {
        const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
        this.audioContext = new AudioContextClass();
        if (this.audioContext) {
          this.masterGain = this.audioContext.createGain();
          this.masterGain.connect(this.audioContext.destination);
          this.masterGain.gain.value = 0.3; // Set default volume to 30%
        }
      } catch (error) {
        console.warn('Web Audio API not supported:', error);
      }
    }
  }

  playTone(frequency: number, duration: number, type: OscillatorType = 'square') {
    if (!this.audioContext || !this.masterGain || this.isMuted) return;
    
    const ctx = this.audioContext;
    const gain = this.masterGain;

    try {
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.type = type;
      oscillator.frequency.value = frequency;

      // Envelope: quick attack, exponential decay
      gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration);

      oscillator.connect(gainNode);
      gainNode.connect(gain);

      oscillator.start(ctx.currentTime);
      oscillator.stop(ctx.currentTime + duration);
    } catch (error) {
      console.warn('Error playing tone:', error);
    }
  }

  private playMelody(notes: Array<{ frequency: number; duration: number }>) {
    if (!this.audioContext || !this.masterGain || this.isMuted) return;

    const ctx = this.audioContext;
    const gain = this.masterGain;
    let currentTime = ctx.currentTime;

    notes.forEach(({ frequency, duration }) => {
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.type = 'square';
      oscillator.frequency.value = frequency;

      gainNode.gain.setValueAtTime(0.2, currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, currentTime + duration);

      oscillator.connect(gainNode);
      gainNode.connect(gain);

      oscillator.start(currentTime);
      oscillator.stop(currentTime + duration);

      currentTime += duration;
    });
  }

  /**
   * Play correct answer sound - ascending happy melody
   */
  playCorrectAnswer() {
    // C4-E4-G4 (happy chord progression)
    this.playMelody([
      { frequency: 262, duration: 0.1 }, // C4
      { frequency: 330, duration: 0.1 }, // E4
      { frequency: 392, duration: 0.2 }, // G4
    ]);
  }

  /**
   * Play wrong answer sound - descending sad melody
   */
  playWrongAnswer() {
    // G4-E4-C4 (sad chord progression)
    this.playMelody([
      { frequency: 392, duration: 0.1 }, // G4
      { frequency: 330, duration: 0.1 }, // E4
      { frequency: 262, duration: 0.2 }, // C4
    ]);
  }

  /**
   * Play attack sound - laser-like effect
   */
  playAttack() {
    if (!this.audioContext || !this.masterGain || this.isMuted) return;

    try {
      const ctx = this.audioContext;
      const gain = this.masterGain;
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.type = 'square';
      oscillator.frequency.setValueAtTime(800, ctx.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.1);

      gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);

      oscillator.connect(gainNode);
      gainNode.connect(gain);

      oscillator.start(ctx.currentTime);
      oscillator.stop(ctx.currentTime + 0.1);
    } catch (error) {
      console.warn('Error playing attack sound:', error);
    }
  }

  /**
   * Play badge/victory sound - triumphant melody
   */
  playBadgeEarned() {
    // C5-C5-G4-A4-C5 (victory melody)
    this.playMelody([
      { frequency: 523, duration: 0.15 }, // C5
      { frequency: 523, duration: 0.15 }, // C5
      { frequency: 392, duration: 0.15 }, // G4
      { frequency: 440, duration: 0.15 }, // A4
      { frequency: 523, duration: 0.3 },  // C5
    ]);
  }

  /**
   * Play gym entry sound - dramatic intro
   */
  playGymEntry() {
    // Low to high sweep
    this.playMelody([
      { frequency: 165, duration: 0.1 }, // E3
      { frequency: 220, duration: 0.1 }, // A3
      { frequency: 330, duration: 0.2 }, // E4
    ]);
  }

  /**
   * Play game over sound - sad descending melody
   */
  playGameOver() {
    // Descending melody
    this.playMelody([
      { frequency: 523, duration: 0.15 }, // C5
      { frequency: 440, duration: 0.15 }, // A4
      { frequency: 392, duration: 0.15 }, // G4
      { frequency: 330, duration: 0.15 }, // E4
      { frequency: 262, duration: 0.3 },  // C4
    ]);
  }

  /**
   * Play background music - Pokémon theme-inspired loop
   */
  playBackgroundMusic() {
    if (!this.audioContext || !this.masterGain || this.isMuted) return;
    
    const ctx = this.audioContext;

    // Pokémon theme-inspired 8-bit melody
    const melody = [
      { frequency: 330, duration: 0.15 }, // E4
      { frequency: 330, duration: 0.15 }, // E4
      { frequency: 330, duration: 0.15 }, // E4
      { frequency: 262, duration: 0.15 }, // C4
      { frequency: 330, duration: 0.15 }, // E4
      { frequency: 392, duration: 0.3 },  // G4
      { frequency: 196, duration: 0.3 },  // G3
      { frequency: 262, duration: 0.15 }, // C4
      { frequency: 196, duration: 0.15 }, // G3
      { frequency: 165, duration: 0.15 }, // E3
      { frequency: 220, duration: 0.15 }, // A3
      { frequency: 247, duration: 0.15 }, // B3
      { frequency: 294, duration: 0.15 }, // D4
      { frequency: 330, duration: 0.3 },  // E4
    ];

    // Loop the melody
    const playLoop = () => {
      this.playMelody(melody);
      // Schedule next loop
      setTimeout(playLoop, melody.reduce((sum, note) => sum + note.duration * 1000, 0));
    };

    playLoop();
  }

  /**
   * Set master volume (0-1)
   */
  setVolume(volume: number) {
    if (this.masterGain) {
      this.masterGain.gain.value = Math.max(0, Math.min(1, volume));
    }
  }

  /**
   * Toggle mute
   */
  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain) {
      this.masterGain.gain.value = this.isMuted ? 0 : 0.3;
    }
    return this.isMuted;
  }

  /**
   * Get mute state
   */
  getMuteState(): boolean {
    return this.isMuted;
  }
}

// Export singleton instance
export const audioManager = new AudioManager();

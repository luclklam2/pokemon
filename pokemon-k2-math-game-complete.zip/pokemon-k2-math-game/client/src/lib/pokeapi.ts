/**
 * PokéAPI Integration Service
 * Fetches official Pokémon data and images from the free public PokéAPI
 */

const POKEAPI_BASE = 'https://pokeapi.co/api/v2';
const SPRITE_BASE = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon';

export interface PokemonData {
  id: number;
  name: string;
  sprites: {
    front_default: string;
    back_default: string;
    front_shiny?: string;
  };
  types: Array<{
    type: {
      name: string;
    };
  }>;
  height: number;
  weight: number;
  base_experience: number;
}

/**
 * Fetch Pokémon data from PokéAPI
 */
export async function fetchPokemonData(pokemonId: number): Promise<PokemonData | null> {
  try {
    const response = await fetch(`${POKEAPI_BASE}/pokemon/${pokemonId}`);
    if (!response.ok) return null;
    return await response.json();
  } catch (error) {
    console.error('Failed to fetch Pokémon data:', error);
    return null;
  }
}

/**
 * Get official Pokémon sprite image URL
 */
export function getPokemonSpriteUrl(pokemonId: number, shiny = false): string {
  const spriteType = shiny ? 'shiny' : 'other/official-artwork';
  return `${SPRITE_BASE}/${spriteType}/${pokemonId}.png`;
}

/**
 * Get classic pixel art sprite (Gen 1 style)
 */
export function getPokemonPixelArtUrl(pokemonId: number): string {
  return `${SPRITE_BASE}/${pokemonId}.png`;
}

/**
 * Fetch multiple Pokémon data
 */
export async function fetchMultiplePokemon(ids: number[]): Promise<PokemonData[]> {
  const promises = ids.map(id => fetchPokemonData(id));
  const results = await Promise.all(promises);
  return results.filter((p): p is PokemonData => p !== null);
}

/**
 * Get Pokémon type color
 */
export function getTypeColor(type: string): string {
  const typeColors: Record<string, string> = {
    normal: '#A8A878',
    fire: '#F08030',
    water: '#6890F0',
    electric: '#F8D030',
    grass: '#78C850',
    ice: '#98D8D8',
    fighting: '#C03028',
    poison: '#A040A0',
    ground: '#E0C068',
    flying: '#A890F0',
    psychic: '#F85888',
    bug: '#A8B820',
    rock: '#B8A038',
    ghost: '#705898',
    dragon: '#7038F8',
    dark: '#705848',
    steel: '#B8B8D0',
    fairy: '#EE99AC',
  };
  return typeColors[type] || '#A8A878';
}

/**
 * Get Pokémon name in Chinese (if available)
 */
export function getPokemonChineseName(englishName: string): string {
  const chineseNames: Record<string, string> = {
    bulbasaur: '妙蛙種子',
    ivysaur: '妙蛙草',
    venusaur: '妙蛙花',
    charmander: '小火龍',
    charmeleon: '火恐龍',
    charizard: '噴火龍',
    squirtle: '傑尼龜',
    wartortle: '烏龜',
    blastoise: '水箭龜',
    caterpie: '綠毛蟲',
    metapod: '鐵甲蛹',
    butterfree: '比比鳥',
    weedle: '毒針蜂',
    kakuna: '鐵甲蛹',
    beedrill: '大針蜂',
    pidgeotto: '比比鳥',
    pidgeot: '比雕',
    rattata: '小老鼠',
    raticate: '大老鼠',
    spearow: '烈雀',
    fearow: '大嘴雀',
    ekans: '阿柏蛇',
    arbok: '阿柏怪',
    pikachu: '皮卡丘',
    raichu: '雷丘',
    ditto: '百變怪',
  };
  return chineseNames[englishName.toLowerCase()] || englishName;
}

/**
 * Cache for Pokémon data to reduce API calls
 */
const pokemonCache = new Map<number, PokemonData>();

/**
 * Fetch with caching
 */
export async function fetchPokemonDataCached(pokemonId: number): Promise<PokemonData | null> {
  if (pokemonCache.has(pokemonId)) {
    return pokemonCache.get(pokemonId) || null;
  }

  const data = await fetchPokemonData(pokemonId);
  if (data) {
    pokemonCache.set(pokemonId, data);
  }
  return data;
}

/**
 * Get list of first generation Pokémon (1-151)
 */
export async function getFirstGenPokemon(): Promise<PokemonData[]> {
  const ids = Array.from({ length: 151 }, (_, i) => i + 1);
  return fetchMultiplePokemon(ids);
}

/**
 * Get specific Pokémon for game (5 starter Pokémon)
 */
export async function getStarterPokemon(): Promise<PokemonData[]> {
  const starterIds = [25, 4, 7, 1, 132]; // Pikachu, Charmander, Squirtle, Bulbasaur, Ditto
  return fetchMultiplePokemon(starterIds);
}

/**
 * Get gym leader Pokémon
 */
export async function getGymLeaderPokemon(): Promise<PokemonData[]> {
  const gymLeaderIds = [25, 6, 9, 3, 149]; // Pikachu, Charizard, Blastoise, Venusaur, Dragonite
  return fetchMultiplePokemon(gymLeaderIds);
}

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface BadgeRewardProps {
  gymId: number;
  onContinue: () => void;
}

const BADGES = [
  { id: 1, name: '新手徽章', emoji: '🔰', color: 'from-red-400 to-red-500' },
  { id: 2, name: '進階徽章', emoji: '⚡', color: 'from-yellow-400 to-yellow-500' },
  { id: 3, name: '大師徽章', emoji: '💎', color: 'from-blue-400 to-blue-500' },
  { id: 4, name: '加法徽章', emoji: '➕', color: 'from-green-400 to-green-500' },
  { id: 5, name: '減法徽章', emoji: '➖', color: 'from-purple-400 to-purple-500' },
];

export default function BadgeReward({ gymId, onContinue }: BadgeRewardProps) {
  const [showAnimation, setShowAnimation] = useState(false);

  useEffect(() => {
    // Trigger animation after component mounts
    setTimeout(() => setShowAnimation(true), 100);
  }, []);

  const badge = BADGES[gymId - 1];

  return (
    <div className="min-h-screen bg-gradient-to-br from-peach-50 via-white to-peach-100 p-4 md:p-8 flex items-center justify-center">
      {/* Decorative background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-mint-200 opacity-40"></div>
        <div className="absolute top-1/3 right-20 w-32 h-32 rounded-full bg-lilac-200 opacity-30"></div>
        <div className="absolute bottom-20 left-1/4 w-24 h-24 bg-yellow-200 opacity-40 rotate-45"></div>
        <div className="absolute bottom-1/3 right-10 w-16 h-16 bg-mint-300 opacity-30 rounded-full"></div>
      </div>

      <div className="relative z-10 max-w-md w-full">
        {/* Celebration text */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-black text-gray-800 mb-2 drop-shadow-lg animate-bounce">
            恭喜！🎉
          </h1>
          <p className="text-2xl font-bold text-gray-700">你已通過道館！</p>
        </div>

        {/* Badge Card */}
        <Card
          className={`bg-gradient-to-br ${badge?.color} p-12 text-center text-white shadow-2xl transform transition-all duration-1000 ${
            showAnimation
              ? 'scale-100 opacity-100'
              : 'scale-0 opacity-0'
          }`}
        >
          <div className="text-9xl mb-6 animate-bounce" style={{ animationDelay: '0.1s' }}>
            {badge?.emoji}
          </div>
          <h2 className="text-4xl font-black mb-4">{badge?.name}</h2>
          <p className="text-lg font-semibold opacity-90">
            你已獲得此徽章！
          </p>
        </Card>

        {/* Confetti animation */}
        {showAnimation && (
          <div className="fixed inset-0 pointer-events-none overflow-hidden">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className="absolute animate-pulse"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-20px`,
                  animation: `fall ${2 + Math.random() * 2}s linear infinite`,
                  fontSize: '24px',
                }}
              >
                {['🎉', '⭐', '✨', '🌟'][Math.floor(Math.random() * 4)]}
              </div>
            ))}
          </div>
        )}

        {/* Continue Button */}
        <div className="mt-12 text-center">
          <Button
            onClick={onContinue}
            className="px-12 py-6 text-2xl font-bold bg-purple-500 hover:bg-purple-600 text-white"
          >
            繼續挑戰
          </Button>
        </div>
      </div>

      <style>{`
        @keyframes fall {
          to {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
}

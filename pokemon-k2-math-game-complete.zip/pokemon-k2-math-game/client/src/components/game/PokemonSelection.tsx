import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { getStarterPokemon, getPokemonChineseName, PokemonData } from '@/lib/pokeapi';

interface PokemonSelectionProps {
  onSelectPokemon: (pokemonName: string, pokemonEmoji: string) => void;
  isLoading?: boolean;
}

const FALLBACK_POKEMON = [
  { name: 'Pikachu', emoji: '⚡', description: '電擊鼠 - 快速且強大' },
  { name: 'Charmander', emoji: '🔥', description: '小火龍 - 火焰攻擊' },
  { name: 'Squirtle', emoji: '💧', description: '傑尼龜 - 水系防禦' },
  { name: 'Bulbasaur', emoji: '🌿', description: '妙蛙種子 - 草系平衡' },
  { name: 'Ditto', emoji: '👾', description: '百變怪 - 變身大師' },
];

export default function PokemonSelection({ onSelectPokemon, isLoading }: PokemonSelectionProps) {
  const [selectedPokemon, setSelectedPokemon] = useState<string | null>(null);
  const [starterPokemon, setStarterPokemon] = useState<PokemonData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadPokemon = async () => {
      try {
        const pokemon = await getStarterPokemon();
        setStarterPokemon(pokemon);
      } catch (error) {
        console.error('Failed to load starter Pokémon:', error);
        setStarterPokemon([]);
      } finally {
        setLoading(false);
      }
    };

    loadPokemon();
  }, []);

  const handleSelect = (pokemon: PokemonData | (typeof FALLBACK_POKEMON[0])) => {
    const name = 'name' in pokemon && 'sprites' in pokemon 
      ? getPokemonChineseName(pokemon.name)
      : pokemon.name;
    const emoji = 'sprites' in pokemon 
      ? pokemon.sprites.front_default
      : pokemon.emoji;
    
    setSelectedPokemon(name);
    onSelectPokemon(name, emoji);
  };

  const pokemonList = starterPokemon.length > 0 ? starterPokemon : FALLBACK_POKEMON;

  return (
    <div className="min-h-screen bg-gradient-to-br from-peach-50 via-white to-peach-100 p-4 md:p-8 flex items-center justify-center">
      {/* Decorative background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-mint-200 opacity-40"></div>
        <div className="absolute top-1/4 right-20 w-40 h-40 rounded-full bg-lilac-200 opacity-30"></div>
        <div className="absolute bottom-20 left-1/4 w-32 h-32 bg-yellow-200 opacity-40 rotate-45"></div>
        <div className="absolute bottom-1/3 right-10 w-24 h-24 bg-mint-300 opacity-30 rounded-full"></div>
      </div>

      <div className="relative z-10 max-w-4xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl md:text-7xl font-black text-gray-800 mb-4 drop-shadow-lg">
            🎮 選擇你的寶可夢！
          </h1>
          <p className="text-2xl font-bold text-gray-700 mb-2">
            選擇一隻寶可夢作為你的夥伴
          </p>
          <p className="text-lg text-gray-600">
            每隻寶可夢都有不同的特性和能力
          </p>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="text-center mb-12">
            <p className="text-xl text-gray-700">載入寶可夢中...</p>
          </div>
        )}

        {/* Pokémon Selection Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-12">
          {pokemonList.map((pokemon) => {
            const pokemonName = 'name' in pokemon && 'sprites' in pokemon 
              ? getPokemonChineseName(pokemon.name)
              : pokemon.name;
            const pokemonImage = 'sprites' in pokemon 
              ? pokemon.sprites.front_default
              : pokemon.emoji;
            const isSelected = selectedPokemon === pokemonName;

            return (
              <Card
                key={pokemonName}
                className={`p-6 cursor-pointer transform transition-all duration-200 hover:scale-105 ${
                  isSelected
                    ? 'bg-gradient-to-br from-purple-300 to-pink-300 border-4 border-purple-600 shadow-2xl'
                    : 'bg-white hover:shadow-lg'
                }`}
                onClick={() => handleSelect(pokemon)}
              >
                <div className="text-center">
                  {pokemonImage.startsWith('http') ? (
                    <img 
                      src={pokemonImage} 
                      alt={pokemonName}
                      className="w-24 h-24 mx-auto mb-4"
                    />
                  ) : (
                    <div className="text-6xl mb-4 animate-bounce">{pokemonImage}</div>
                  )}
                  <h3 className="text-lg font-bold text-gray-800 mb-2">{pokemonName}</h3>
                  {isSelected && (
                    <div className="mt-4 text-xl font-bold text-purple-700">✓ 已選擇</div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>

        {/* Info Card */}
        <Card className="bg-gradient-to-r from-purple-100 to-pink-100 p-8 mb-8 shadow-lg">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">💡 提示</h2>
          <p className="text-lg text-gray-700 mb-3">
            選擇你喜歡的寶可夢後，你將進入道館戰鬥。答對題目時，你的寶可夢會攻擊對手！
          </p>
          <p className="text-lg text-gray-700">
            答錯題目時，你的寶可夢會受到傷害。保護好你的寶可夢吧！
          </p>
        </Card>

        {/* Action Button */}
        <div className="text-center">
          <Button
            onClick={() => selectedPokemon && handleSelect(pokemonList.find(p => {
              const name = 'name' in p && 'sprites' in p ? getPokemonChineseName(p.name) : p.name;
              return name === selectedPokemon;
            })!)}
            disabled={!selectedPokemon || isLoading || loading}
            className="px-16 py-8 text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-xl disabled:opacity-50"
          >
            {isLoading || loading ? '準備中...' : selectedPokemon ? `開始冒險 - ${selectedPokemon}` : '請先選擇寶可夢'}
          </Button>
        </div>
      </div>
    </div>
  );
}

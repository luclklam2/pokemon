import { useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { audioManager } from '@/lib/audioManager';
import '../../styles/pixel-art.css';

export default function SoundControl() {
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.3);

  const handleToggleMute = () => {
    const newMuteState = audioManager.toggleMute();
    setIsMuted(newMuteState);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    audioManager.setVolume(newVolume);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 flex items-center gap-4 pixel-card bg-white">
      <button
        onClick={handleToggleMute}
        className="p-2 hover:bg-gray-200 rounded transition-colors"
        title={isMuted ? '取消靜音' : '靜音'}
      >
        {isMuted ? (
          <VolumeX className="w-6 h-6 text-red-600" />
        ) : (
          <Volume2 className="w-6 h-6 text-green-600" />
        )}
      </button>
      <input
        type="range"
        min="0"
        max="1"
        step="0.1"
        value={volume}
        onChange={handleVolumeChange}
        className="w-24 cursor-pointer"
        title="音量"
      />
    </div>
  );
}

import { Heart } from 'lucide-react';

interface HPBarProps {
  currentHP: number;
  maxHP: number;
  showLabel?: boolean;
}

export default function HPBar({ currentHP, maxHP, showLabel = true }: HPBarProps) {
  const percentage = (currentHP / maxHP) * 100;
  
  const getBarColor = () => {
    if (percentage > 50) return 'bg-green-500';
    if (percentage > 25) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="w-full">
      {showLabel && (
        <div className="flex justify-between mb-2">
          <span className="font-bold text-gray-800">HP</span>
          <span className="font-bold text-gray-800">{currentHP}/{maxHP}</span>
        </div>
      )}
      <div className="w-full bg-gray-300 rounded-full h-8 overflow-hidden border-2 border-gray-800">
        <div
          className={`h-full ${getBarColor()} transition-all duration-300 flex items-center justify-center`}
          style={{ width: `${percentage}%` }}
        >
          {percentage > 20 && (
            <span className="text-white font-bold text-sm drop-shadow-lg">
              {currentHP > 0 ? '❤️' : ''}
            </span>
          )}
        </div>
      </div>
      
      {/* Heart indicators */}
      <div className="flex gap-1 mt-2">
        {Array.from({ length: maxHP }).map((_, i) => (
          <div
            key={i}
            className={`w-6 h-6 rounded-full flex items-center justify-center border-2 border-gray-800 ${
              i < currentHP ? 'bg-red-500' : 'bg-gray-200'
            }`}
          >
            {i < currentHP && <Heart className="w-4 h-4 fill-white text-white" />}
          </div>
        ))}
      </div>
    </div>
  );
}

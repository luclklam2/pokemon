import { useState, useEffect } from 'react';
import HPBar from './HPBar';
import '../../styles/pixel-art.css';

interface BattleSceneProps {
  playerPokemon: {
    name: string;
    emoji: string;
    hp: number;
    maxHP: number;
  };
  opponentPokemon: {
    name: string;
    emoji: string;
    hp: number;
    maxHP: number;
    leaderName: string;
  };
  isAttacking?: boolean;
  attackType?: 'player' | 'opponent';
}

export default function BattleScene({
  playerPokemon,
  opponentPokemon,
  isAttacking = false,
  attackType,
}: BattleSceneProps) {
  const [showAttackEffect, setShowAttackEffect] = useState(false);

  useEffect(() => {
    if (isAttacking) {
      setShowAttackEffect(true);
      const timer = setTimeout(() => setShowAttackEffect(false), 500);
      return () => clearTimeout(timer);
    }
  }, [isAttacking]);

  return (
    <div className="w-full pixel-card bg-blue-300 mb-8 relative overflow-hidden">
      {/* Pixel art battle background */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
        backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(0,0,0,.05) 35px, rgba(0,0,0,.05) 70px)'
      }}></div>

      <div className="relative z-10 p-8">
        {/* Opponent Pokémon (Top) */}
        <div className="mb-12">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm font-bold text-gray-700">{opponentPokemon.leaderName}</p>
              <p className="text-lg font-black text-gray-800">{opponentPokemon.name}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-bold text-gray-600">HP</p>
              <p className="text-lg font-black text-gray-800">
                {opponentPokemon.hp}/{opponentPokemon.maxHP}
              </p>
            </div>
          </div>
          
          {/* HP Bar */}
          <div className="pixel-hp-bar">
            <div
              className={`pixel-hp-fill ${
                opponentPokemon.hp > opponentPokemon.maxHP * 0.5
                  ? ''
                  : opponentPokemon.hp > opponentPokemon.maxHP * 0.25
                  ? 'low'
                  : 'critical'
              }`}
              style={{
                width: `${(opponentPokemon.hp / opponentPokemon.maxHP) * 100}%`,
              }}
            ></div>
          </div>

          {/* Opponent Pokémon Sprite */}
          <div
            className={`text-8xl text-center mt-8 transform transition-all duration-300 ${
              attackType === 'player' && showAttackEffect ? 'scale-110 -translate-x-4' : 'scale-100'
            }`}
          >
            {opponentPokemon.emoji}
          </div>
        </div>

        {/* VS Divider */}
        <div className="flex items-center justify-center my-8">
          <div className="flex-1 h-2 bg-black border-t-2 border-b-2 border-black"></div>
          <div className="px-6 font-black text-2xl text-gray-800 bg-white border-4 border-black">VS</div>
          <div className="flex-1 h-2 bg-black border-t-2 border-b-2 border-black"></div>
        </div>

        {/* Player Pokémon (Bottom) */}
        <div>
          {/* Player Pokémon Sprite */}
          <div
            className={`text-8xl text-center mb-8 transform transition-all duration-300 ${
              attackType === 'opponent' && showAttackEffect ? 'scale-110 translate-x-4' : 'scale-100'
            }`}
          >
            {playerPokemon.emoji}
          </div>

          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm font-bold text-gray-700">你的寶可夢</p>
              <p className="text-lg font-black text-gray-800">{playerPokemon.name}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-bold text-gray-600">HP</p>
              <p className="text-lg font-black text-gray-800">
                {playerPokemon.hp}/{playerPokemon.maxHP}
              </p>
            </div>
          </div>

          {/* HP Bar */}
          <div className="pixel-hp-bar">
            <div
              className={`pixel-hp-fill ${
                playerPokemon.hp > playerPokemon.maxHP * 0.5
                  ? ''
                  : playerPokemon.hp > playerPokemon.maxHP * 0.25
                  ? 'low'
                  : 'critical'
              }`}
              style={{
                width: `${(playerPokemon.hp / playerPokemon.maxHP) * 100}%`,
              }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
}

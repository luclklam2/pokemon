import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface GameOverProps {
  gymId: number;
  onRetry: () => void;
  onBackToSelection: () => void;
}

const GYM_NAMES = [
  '新手道館',
  '進階道館',
  '大師道館',
  '加法道館',
  '減法道館',
];

export default function GameOver({ gymId, onRetry, onBackToSelection }: GameOverProps) {
  const gymName = GYM_NAMES[gymId - 1];

  return (
    <div className="min-h-screen bg-gradient-to-br from-peach-50 via-white to-peach-100 p-4 md:p-8 flex items-center justify-center">
      {/* Decorative background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-10 w-20 h-20 rounded-full bg-mint-200 opacity-40"></div>
        <div className="absolute top-1/3 right-20 w-32 h-32 rounded-full bg-lilac-200 opacity-30"></div>
        <div className="absolute bottom-20 left-1/4 w-24 h-24 bg-yellow-200 opacity-40 rotate-45"></div>
      </div>

      <div className="relative z-10 max-w-md w-full">
        {/* Game Over Message */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-black text-gray-800 mb-2 drop-shadow-lg">
            遊戲結束 😢
          </h1>
          <p className="text-2xl font-bold text-gray-700">
            你在 {gymName} 中失敗了
          </p>
        </div>

        {/* Game Over Card */}
        <Card className="bg-gradient-to-br from-red-100 to-red-200 p-8 text-center shadow-xl mb-8">
          <div className="text-8xl mb-6">💔</div>
          <p className="text-xl font-bold text-gray-800 mb-4">
            你已用完所有生命值
          </p>
          <p className="text-lg text-gray-700">
            不要放棄！再試一次，你一定可以通過！
          </p>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col gap-4">
          <Button
            onClick={onRetry}
            className="w-full px-8 py-6 text-xl font-bold bg-green-500 hover:bg-green-600 text-white"
          >
            重新挑戰
          </Button>
          <Button
            onClick={onBackToSelection}
            variant="outline"
            className="w-full px-8 py-6 text-xl font-bold text-gray-800 border-2 border-gray-800 hover:bg-gray-100"
          >
            返回道館選擇
          </Button>
        </div>

        {/* Encouragement */}
        <div className="mt-8 text-center">
          <p className="text-lg font-semibold text-gray-700">
            💪 加油！你可以做到的！
          </p>
        </div>
      </div>
    </div>
  );
}

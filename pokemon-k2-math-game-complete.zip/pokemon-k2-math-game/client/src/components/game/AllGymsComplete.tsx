import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface AllGymsCompleteProps {
  onBackToHome: () => void;
}

export default function AllGymsComplete({ onBackToHome }: AllGymsCompleteProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-peach-50 via-white to-peach-100 p-4 md:p-8 flex items-center justify-center">
      {/* Decorative background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-mint-200 opacity-40"></div>
        <div className="absolute top-1/4 right-20 w-40 h-40 rounded-full bg-lilac-200 opacity-30"></div>
        <div className="absolute bottom-20 left-1/4 w-32 h-32 bg-yellow-200 opacity-40 rotate-45"></div>
        <div className="absolute bottom-1/3 right-10 w-24 h-24 bg-mint-300 opacity-30 rounded-full"></div>
      </div>

      <div className="relative z-10 max-w-2xl w-full">
        {/* Celebration Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl md:text-7xl font-black text-gray-800 mb-4 drop-shadow-lg animate-bounce">
            🎉 完成！🎉
          </h1>
          <p className="text-3xl font-bold text-gray-700 mb-2">
            你已通過所有道館！
          </p>
          <p className="text-xl text-gray-600">
            恭喜成為寶可夢數學大師！
          </p>
        </div>

        {/* All Badges Display */}
        <Card className="bg-gradient-to-br from-purple-100 to-pink-100 p-12 mb-8 shadow-2xl">
          <h2 className="text-3xl font-black text-center text-gray-800 mb-8">
            你已獲得所有 5 個徽章！
          </h2>

          <div className="grid grid-cols-5 gap-4 mb-8">
            {[
              { emoji: '🔰', name: '新手' },
              { emoji: '⚡', name: '進階' },
              { emoji: '💎', name: '大師' },
              { emoji: '➕', name: '加法' },
              { emoji: '➖', name: '減法' },
            ].map((badge, i) => (
              <div
                key={i}
                className="flex flex-col items-center justify-center p-4 bg-white rounded-lg shadow-lg transform hover:scale-110 transition-transform duration-200"
                style={{
                  animation: `slideIn 0.5s ease-out ${i * 0.1}s backwards`,
                }}
              >
                <div className="text-5xl mb-2">{badge.emoji}</div>
                <p className="text-sm font-bold text-gray-800 text-center">{badge.name}</p>
              </div>
            ))}
          </div>

          {/* Stats */}
          <div className="bg-white rounded-lg p-6 text-center">
            <p className="text-2xl font-bold text-gray-800 mb-2">
              ✨ 你已完成 100 道題目！✨
            </p>
            <p className="text-lg text-gray-700">
              你是真正的數學冠軍！
            </p>
          </div>
        </Card>

        {/* Confetti Animation */}
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={i}
            className="fixed pointer-events-none animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `-20px`,
              animation: `fall ${2 + Math.random() * 3}s linear infinite`,
              fontSize: '24px',
              zIndex: 0,
            }}
          >
            {['🎉', '⭐', '✨', '🌟', '🏆'][Math.floor(Math.random() * 5)]}
          </div>
        ))}

        {/* Action Buttons */}
        <div className="flex flex-col gap-4 text-center">
          <Button
            onClick={onBackToHome}
            className="w-full px-12 py-8 text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-xl"
          >
            返回首頁
          </Button>
          <p className="text-lg font-semibold text-gray-700 mt-4">
            🎮 想再玩一次嗎？點擊返回首頁重新開始！
          </p>
        </div>
      </div>

      <style>{`
        @keyframes fall {
          to {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0;
          }
        }
        @keyframes slideIn {
          from {
            transform: scale(0) translateY(-20px);
            opacity: 0;
          }
          to {
            transform: scale(1) translateY(0);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  );
}

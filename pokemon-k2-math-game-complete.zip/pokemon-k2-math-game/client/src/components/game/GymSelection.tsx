import { Lock, Trophy } from 'lucide-react';
import { useEffect, useState } from 'react';
import { trpc } from '@/lib/trpc';
import '../../styles/pixel-art.css';

interface GymSelectionProps {
  progress: Array<{ gymId: number; isCompleted: boolean; badgeEarned: boolean }>;
  onSelectGym: (gymId: number) => void;
  isLoading: boolean;
}

const GYM_INFO = [
  {
    id: 1,
    name: '新手道館',
    description: '1-20 數字排序',
    emoji: '🔰',
    color: 'bg-red-400',
  },
  {
    id: 2,
    name: '進階道館',
    description: '1-50 數字排序',
    emoji: '⚡',
    color: 'bg-yellow-400',
  },
  {
    id: 3,
    name: '大師道館',
    description: '1-100 數字排序',
    emoji: '💎',
    color: 'bg-blue-400',
  },
  {
    id: 4,
    name: '加法道館',
    description: '個位數加法',
    emoji: '➕',
    color: 'bg-green-400',
  },
  {
    id: 5,
    name: '減法道館',
    description: '個位數減法',
    emoji: '➖',
    color: 'bg-purple-400',
  },
];

export default function GymSelection({ progress, onSelectGym, isLoading }: GymSelectionProps) {
  const [unlockedGyms, setUnlockedGyms] = useState<Set<number>>(new Set());

  // Check which gyms are unlocked
  const checkUnlocked = async () => {
    const unlocked = new Set<number>();
    unlocked.add(1); // Gym 1 is always unlocked

    for (let i = 2; i <= 5; i++) {
      const completed = progress.find(p => p.gymId === i - 1)?.isCompleted;
      if (completed) {
        unlocked.add(i);
      }
    }

    setUnlockedGyms(unlocked);
  };

  useEffect(() => {
    checkUnlocked();
  }, [progress]);

  const isGymCompleted = (gymId: number) => {
    return progress.find(p => p.gymId === gymId)?.isCompleted || false;
  };

  return (
    <div className="min-h-screen pixel-bg-sky p-4 md:p-8 relative overflow-hidden">
      {/* Pixel art clouds */}
      <div className="absolute top-10 left-10 w-32 h-16 bg-white border-2 border-black" style={{
        clipPath: 'polygon(0 50%, 10% 30%, 20% 20%, 30% 25%, 40% 15%, 50% 20%, 60% 25%, 70% 20%, 80% 30%, 90% 50%, 100% 50%, 100% 100%, 0 100%)'
      }}></div>

      {/* Title */}
      <h1 className="text-5xl font-black text-center text-yellow-300 drop-shadow-lg mb-12 pixel-text-shadow relative z-10" style={{
        fontFamily: "'Press Start 2P', cursive",
        fontSize: '2rem'
      }}>
        道館選擇
      </h1>

      {/* Gym grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto relative z-10">
        {GYM_INFO.map((gym) => {
          const isUnlocked = unlockedGyms.has(gym.id);
          const isCompleted = isGymCompleted(gym.id);

          return (
            <div
              key={gym.id}
              className={`pixel-card ${gym.color} ${!isUnlocked ? 'opacity-50' : ''} cursor-pointer transform hover:scale-105 transition-all`}
              onClick={() => isUnlocked && onSelectGym(gym.id)}
            >
              <div className="text-center">
                {/* Gym icon */}
                <div className="text-5xl mb-4">{gym.emoji}</div>

                {/* Gym name */}
                <h2 className="text-xl font-black text-gray-800 mb-2">{gym.name}</h2>

                {/* Gym description */}
                <p className="text-gray-700 font-bold mb-4 text-sm">{gym.description}</p>

                {/* Status */}
                {isCompleted && (
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <Trophy className="w-6 h-6 text-yellow-500" />
                    <span className="font-bold text-gray-800">已完成</span>
                  </div>
                )}

                {!isUnlocked && (
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <Lock className="w-6 h-6 text-gray-600" />
                    <span className="font-bold text-gray-600">已鎖定</span>
                  </div>
                )}

                {/* Button */}
                {isUnlocked && (
                  <button
                    className="pixel-button w-full text-sm"
                    disabled={isLoading}
                  >
                    {isLoading ? '載入中...' : '進入'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Pixel art trees at bottom */}
      <div className="absolute bottom-0 left-0 w-full h-40 flex justify-around pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="flex flex-col items-center">
            <div className="w-6 h-24 bg-amber-900 border border-black"></div>
            <div className="w-20 h-20 bg-green-700 border border-black" style={{
              clipPath: 'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)'
            }}></div>
          </div>
        ))}
      </div>
    </div>
  );
}

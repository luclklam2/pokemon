import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import BattleScene from './BattleScene';
import { audioManager } from '@/lib/audioManager';
import SoundControl from './SoundControl';
import '../../styles/pixel-art.css';

interface GamePlayProps {
  sessionId: number;
  gymId: number;
  onGameComplete: (status: 'completed' | 'failed') => void;
}

interface PokemonData {
  name: string;
  emoji: string;
  hp: number;
  maxHP: number;
}

interface OpponentPokemonData extends PokemonData {
  leaderName: string;
}

export default function GamePlay({ sessionId, gymId, onGameComplete }: GamePlayProps) {
  // All hooks must be at the top level
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswering, setIsAnswering] = useState(false);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; message: string } | null>(null);
  const [playerPokemon, setPlayerPokemon] = useState<PokemonData | null>(null);
  const [opponentPokemon, setOpponentPokemon] = useState<OpponentPokemonData | null>(null);
  const [sessionData, setSessionData] = useState<any>(null);
  const [isAttacking, setIsAttacking] = useState(false);
  const [attackType, setAttackType] = useState<'player' | 'opponent' | undefined>(undefined);

  // Fetch player's Pokémon
  const playerPokemonQuery = trpc.game.getPlayerPokemon.useQuery();

  // Fetch current question
  const currentQuestionQuery = trpc.game.getCurrentQuestion.useQuery(
    { sessionId },
    { refetchInterval: false }
  );

  // Fetch session summary
  const sessionSummaryQuery = trpc.game.getSessionSummary.useQuery(
    { sessionId },
    { refetchInterval: 2000 }
  );

  // Submit answer mutation
  const submitAnswerMutation = trpc.game.submitAnswer.useMutation({
    onSuccess: (data) => {
      // Play audio effects
      if (data.isCorrect) {
        audioManager.playCorrectAnswer();
        audioManager.playAttack();
      } else {
        audioManager.playWrongAnswer();
      }

      // Show attack animation
      setIsAttacking(true);
      setAttackType(data.isCorrect ? 'player' : 'opponent');

      setFeedback({
        isCorrect: data.isCorrect,
        message: data.isCorrect ? '答對了！寶可夢出招！🎉' : '答錯了！受到傷害！',
      });

      setTimeout(() => {
        setIsAttacking(false);
        setAttackType(undefined);

        if (data.sessionStatus === 'completed') {
          audioManager.playBadgeEarned();
          onGameComplete('completed');
        } else if (data.sessionStatus === 'failed') {
          audioManager.playGameOver();
          onGameComplete('failed');
        } else {
          // Move to next question
          setSelectedAnswer(null);
          setFeedback(null);
          currentQuestionQuery.refetch();
        }
      }, 1500);
    },
    onError: (error) => {
      console.error('Failed to submit answer:', error);
      setFeedback({
        isCorrect: false,
        message: '提交失敗，請重試',
      });
    },
  });

  // Update session data
  useEffect(() => {
    if (sessionSummaryQuery.data) {
      setSessionData(sessionSummaryQuery.data);
    }
  }, [sessionSummaryQuery.data]);

  // Set player Pokémon when loaded
  useEffect(() => {
    if (playerPokemonQuery.data && sessionData) {
      setPlayerPokemon({
        name: playerPokemonQuery.data.pokemonName,
        emoji: playerPokemonQuery.data.pokemonEmoji,
        hp: sessionData.playerHP,
        maxHP: 100,
      });
    }
  }, [playerPokemonQuery.data, sessionData]);

  // Set opponent Pokémon when question loads
  useEffect(() => {
    if (currentQuestionQuery.data && sessionData && !opponentPokemon) {
      const opponents: Record<number, any> = {
        1: { name: 'Pikachu', emoji: '⚡', leaderName: '小智', maxHP: 80 },
        2: { name: 'Charizard', emoji: '🔥', leaderName: '火焰館主', maxHP: 100 },
        3: { name: 'Blastoise', emoji: '💧', leaderName: '水之館主', maxHP: 100 },
        4: { name: 'Venusaur', emoji: '🌿', leaderName: '草之館主', maxHP: 100 },
        5: { name: 'Dragonite', emoji: '🐉', leaderName: '龍之館主', maxHP: 120 },
      };
      const opponent = opponents[gymId] || opponents[1];
      setOpponentPokemon({
        ...opponent,
        hp: sessionData.opponentHP,
      });
      // Play gym entry sound
      audioManager.playGymEntry();
    }
  }, [currentQuestionQuery.data, sessionData, gymId, opponentPokemon]);

  // Play background music on mount
  useEffect(() => {
    audioManager.playBackgroundMusic();
    return () => {
      // Cleanup if needed
    };
  }, []);

  const handleSubmitAnswer = () => {
    if (!selectedAnswer || !currentQuestionQuery.data) return;

    // Play submit sound
    audioManager.playTone(523, 0.15);

    setIsAnswering(true);
    submitAnswerMutation.mutate({
      sessionId,
      questionId: currentQuestionQuery.data.id,
      answer: selectedAnswer,
    });
  };

  // Loading state
  if (!currentQuestionQuery.data || !playerPokemon || !opponentPokemon || !sessionData) {
    return (
      <div className="min-h-screen pixel-bg-sky flex items-center justify-center">
        <div className="pixel-card bg-white text-center">
          <p className="text-xl font-bold text-gray-800">載入中...</p>
        </div>
      </div>
    );
  }

  const question = currentQuestionQuery.data;
  const currentQuestionNum = sessionData.answeredCount + 1;
  const totalQuestions = sessionData.totalQuestions;

  return (
    <div className="min-h-screen pixel-bg-sky flex flex-col p-4 relative">
      <SoundControl />

      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <div className="pixel-card bg-yellow-300 px-4 py-2">
          <p className="pixel-font text-sm font-bold">
            第 {currentQuestionNum} / {totalQuestions} 題
          </p>
        </div>
        <div className="pixel-card bg-green-300 px-4 py-2">
          <p className="pixel-font text-sm font-bold">
            徽章: {sessionData.badgesEarned}
          </p>
        </div>
      </div>

      {/* Battle Scene */}
      {playerPokemon && opponentPokemon && (
        <BattleScene
          playerPokemon={playerPokemon}
          opponentPokemon={opponentPokemon}
          isAttacking={isAttacking}
          attackType={attackType}
        />
      )}

      {/* Question Card */}
      <div className="pixel-card bg-white mt-6 mb-4">
        <h2 className="pixel-font text-lg font-bold text-center mb-4 text-gray-800">
          {question.question}
        </h2>

        {/* Answer Options */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {question.options.map((option: string, index: number) => (
            <button
              key={index}
              onClick={() => setSelectedAnswer(option)}
              disabled={isAnswering}
              className={`pixel-button text-sm font-bold transition-all ${
                selectedAnswer === option
                  ? 'bg-yellow-300 scale-105'
                  : 'bg-blue-300 hover:bg-blue-400'
              } ${isAnswering ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {option}
            </button>
          ))}
        </div>

        {/* Feedback */}
        {feedback && (
          <div
            className={`pixel-card text-center py-2 mb-4 ${
              feedback.isCorrect ? 'bg-green-300' : 'bg-red-300'
            }`}
          >
            <p className="pixel-font font-bold text-gray-800">
              {feedback.message}
            </p>
          </div>
        )}

        {/* Submit Button */}
        <button
          onClick={handleSubmitAnswer}
          disabled={!selectedAnswer || isAnswering}
          className="w-full pixel-button text-lg font-bold bg-red-500 text-white disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isAnswering ? '提交中...' : '提交答案'}
        </button>
      </div>
    </div>
  );
}

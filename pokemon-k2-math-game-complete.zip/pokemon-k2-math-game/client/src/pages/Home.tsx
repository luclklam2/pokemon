import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import '../styles/pixel-art.css';

export default function Home() {
  const { isAuthenticated, logout, user } = useAuth();
  const [, setLocation] = useLocation();

  const handleStartGame = () => {
    setLocation('/game');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen pixel-bg-sky flex flex-col items-center justify-center p-4">
        <div className="text-center mb-8">
          <h1 className="text-6xl font-black text-yellow-400 drop-shadow-lg mb-4 pixel-text-shadow" style={{
            fontFamily: "'Press Start 2P', cursive",
            fontSize: '2.5rem',
            letterSpacing: '4px'
          }}>
            POKÉMON
          </h1>
          <p className="text-3xl font-bold text-white drop-shadow-lg pixel-text-shadow" style={{
            fontFamily: "'Press Start 2P', cursive",
            fontSize: '1rem'
          }}>
            數學冒險
          </p>
        </div>
        <button
          onClick={() => window.location.href = getLoginUrl()}
          className="pixel-button text-xl"
        >
          登入
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen pixel-bg-sky flex flex-col relative overflow-hidden">
      {/* Pixel art clouds */}
      <div className="absolute top-10 left-10 w-32 h-16 bg-white border-2 border-black" style={{
        clipPath: 'polygon(0 50%, 10% 30%, 20% 20%, 30% 25%, 40% 15%, 50% 20%, 60% 25%, 70% 20%, 80% 30%, 90% 50%, 100% 50%, 100% 100%, 0 100%)'
      }}></div>
      <div className="absolute top-24 right-16 w-40 h-20 bg-white border-2 border-black" style={{
        clipPath: 'polygon(0 50%, 10% 30%, 20% 20%, 30% 25%, 40% 15%, 50% 20%, 60% 25%, 70% 20%, 80% 30%, 90% 50%, 100% 50%, 100% 100%, 0 100%)'
      }}></div>

      {/* Navigation bar */}
      <nav className="relative z-20 flex justify-between items-center p-6 bg-red-600 border-b-4 border-black">
        <h1 className="text-3xl font-black text-yellow-300 drop-shadow-lg pixel-text-shadow" style={{
          fontFamily: "'Press Start 2P', cursive",
          fontSize: '1rem'
        }}>
          POKÉMON 數學
        </h1>
        <div className="flex gap-4 items-center">
          <span className="text-white font-bold text-lg drop-shadow-lg pixel-text-shadow">
            {user?.name}
          </span>
          <button
            onClick={logout}
            className="pixel-button bg-yellow-300 text-black hover:bg-yellow-400 text-sm"
          >
            登出
          </button>
        </div>
      </nav>

      {/* Main content */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 relative z-10">
        {/* Title */}
        <h2 className="text-5xl font-black text-yellow-300 drop-shadow-lg mb-4 text-center pixel-text-shadow" style={{
          fontFamily: "'Press Start 2P', cursive",
          fontSize: '1.5rem'
        }}>
          歡迎，訓練家！
        </h2>

        {/* Game info cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-4xl">
          {/* Card 1 */}
          <div className="pixel-card bg-yellow-300">
            <div className="text-4xl mb-2 text-center">📚</div>
            <h3 className="text-lg font-black text-gray-800 mb-2 text-center">100 道題目</h3>
            <p className="text-gray-700 font-bold text-center text-sm">從簡單到困難的數學挑戰</p>
          </div>

          {/* Card 2 */}
          <div className="pixel-card bg-blue-300">
            <div className="text-4xl mb-2 text-center">🏆</div>
            <h3 className="text-lg font-black text-gray-800 mb-2 text-center">5 個道館</h3>
            <p className="text-gray-700 font-bold text-center text-sm">挑戰館主，贏得徽章</p>
          </div>

          {/* Card 3 */}
          <div className="pixel-card bg-green-300">
            <div className="text-4xl mb-2 text-center">⚡</div>
            <h3 className="text-lg font-black text-gray-800 mb-2 text-center">寶可夢戰鬥</h3>
            <p className="text-gray-700 font-bold text-center text-sm">用寶可夢戰勝對手</p>
          </div>
        </div>

        {/* Start button */}
        <button
          onClick={handleStartGame}
          className="pixel-button text-2xl mb-12 transform hover:scale-110"
        >
          開始冒險！
        </button>

        {/* Disclaimer link */}
        <div className="mb-8">
          <button
            onClick={() => setLocation('/disclaimer')}
            className="pixel-font text-xs underline"
            style={{ color: '#0000FF' }}
          >
            免責聲明
          </button>
        </div>

        {/* Instructions */}
        <div className="pixel-card bg-white max-w-2xl">
          <h3 className="text-xl font-black text-gray-800 mb-4 text-center">遊戲說明：</h3>
          <ul className="text-gray-700 font-bold space-y-2 text-sm">
            <li>✓ 選擇你的寶可夢夥伴</li>
            <li>✓ 選擇一個道館進行挑戰</li>
            <li>✓ 答對題目，寶可夢就會攻擊對手</li>
            <li>✓ 扣完對手 HP 就贏得徽章</li>
            <li>✓ 集齊所有 5 個徽章成為數學大師！</li>
          </ul>
        </div>
      </div>

      {/* Pixel art trees at bottom */}
      <div className="absolute bottom-0 left-0 w-full h-40 flex justify-around pointer-events-none">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="flex flex-col items-center">
            <div className="w-6 h-24 bg-amber-900 border border-black"></div>
            <div className="w-20 h-20 bg-green-700 border border-black" style={{
              clipPath: 'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)'
            }}></div>
          </div>
        ))}
      </div>
    </div>
  );
}

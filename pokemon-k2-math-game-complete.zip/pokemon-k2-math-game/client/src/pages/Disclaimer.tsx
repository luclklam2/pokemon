import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';

export default function Disclaimer() {
  const [, setLocation] = useLocation();

  return (
    <div className="pixel-background min-h-screen flex flex-col items-center justify-center p-4">
      <div className="pixel-card max-w-2xl w-full p-8">
        <h1 className="pixel-font text-4xl text-center mb-6" style={{ color: '#FFD700' }}>
          免責聲明
        </h1>
        
        <div className="pixel-font text-sm leading-relaxed space-y-4 mb-8">
          <p>
            <strong>寶可夢 K2 數學挑戰</strong> 是一個非官方的教育遊戲，旨在幫助香港 K2 學生學習數學。
          </p>

          <p>
            <strong>版權聲明：</strong>
          </p>
          <ul className="list-disc list-inside space-y-2 ml-4">
            <li>Pokémon、Pokéball 和相關商標是任天堂、Game Freak 和 The Pokémon Company 的商標。</li>
            <li>本遊戲不隸屬於任天堂、Game Freak 或 The Pokémon Company。</li>
            <li>本遊戲僅供教育和非商業用途使用。</li>
          </ul>

          <p>
            <strong>資源歸屬：</strong>
          </p>
          <ul className="list-disc list-inside space-y-2 ml-4">
            <li>像素藝術資源來自 itch.io 上的開源資源和免費資源。</li>
            <li>音效由 Web Audio API 生成。</li>
            <li>所有資源的使用均遵守其各自的許可證。</li>
          </ul>

          <p>
            <strong>使用條款：</strong>
          </p>
          <ul className="list-disc list-inside space-y-2 ml-4">
            <li>本遊戲僅供個人教育用途使用。</li>
            <li>禁止用於商業目的。</li>
            <li>禁止修改或重新分發本遊戲。</li>
          </ul>

          <p>
            如果你對本遊戲的任何方面有疑問，請聯繫開發者。
          </p>
        </div>

        <div className="flex gap-4 justify-center">
          <Button
            onClick={() => setLocation('/')}
            className="pixel-button"
            style={{
              backgroundColor: '#FF0000',
              color: 'white',
              border: '3px solid black',
              fontSize: '16px',
              padding: '12px 24px',
            }}
          >
            返回首頁
          </Button>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { useAuth } from '@/_core/hooks/useAuth';
import { useLocation } from 'wouter';
import PokemonSelection from '@/components/game/PokemonSelection';
import GymSelection from '@/components/game/GymSelection';
import GamePlay from '@/components/game/GamePlay';
import GameOver from '@/components/game/GameOver';
import BadgeReward from '@/components/game/BadgeReward';
import AllGymsComplete from '@/components/game/AllGymsComplete';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

type GameState = 'pokemon-selection' | 'gym-selection' | 'playing' | 'badge-reward' | 'game-over' | 'loading' | 'all-complete';

export default function Game() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [gameState, setGameState] = useState<GameState>('pokemon-selection');
  const [currentGymId, setCurrentGymId] = useState<number | null>(null);
  const [currentSessionId, setCurrentSessionId] = useState<number | null>(null);
  const [sessionStatus, setSessionStatus] = useState<'active' | 'completed' | 'failed'>('active');
  const [selectedPokemon, setSelectedPokemon] = useState<{ name: string; emoji: string } | null>(null);

  const progressQuery = trpc.game.getProgress.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // Check if all gyms are completed
  const allGymsCompleted = progressQuery.data && progressQuery.data.length === 5 && progressQuery.data.every(p => p.isCompleted);

  const selectPokemonMutation = trpc.game.selectPokemon.useMutation({
    onSuccess: () => {
      setGameState('gym-selection');
    },
    onError: (error) => {
      console.error('Failed to select Pokémon:', error);
      alert(error.message || '無法選擇寶可夢');
    },
  });

  const startSessionMutation = trpc.game.startSession.useMutation({
    onSuccess: (data) => {
      setCurrentSessionId(data.sessionId);
      setCurrentGymId(data.gymId);
      setGameState('playing');
    },
    onError: (error) => {
      console.error('Failed to start session:', error);
      alert(error.message || '無法開始遊戲');
    },
  });

  const handleSelectPokemon = (pokemonName: string, pokemonEmoji: string) => {
    setSelectedPokemon({ name: pokemonName, emoji: pokemonEmoji });
    selectPokemonMutation.mutate({ pokemonName, pokemonEmoji });
  };

  const handleStartGym = async (gymId: number) => {
    setGameState('loading');
    startSessionMutation.mutate({ gymId });
  };

  const handleGameComplete = (status: 'completed' | 'failed') => {
    setSessionStatus(status);
    if (status === 'completed') {
      setGameState('badge-reward');
    } else {
      setGameState('game-over');
    }
  };

  const handleRetry = () => {
    if (currentGymId) {
      handleStartGym(currentGymId);
    }
  };

  const handleBackToSelection = () => {
    setGameState('gym-selection');
    setCurrentGymId(null);
    setCurrentSessionId(null);
    progressQuery.refetch();
  };

  const handleBackToHome = () => {
    setLocation('/');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-peach-50 to-peach-100">
        <div className="text-center">
          <p className="text-xl font-bold text-gray-800 mb-4">請登入以開始遊戲</p>
          <Button onClick={() => window.location.href = '/login'}>登入</Button>
        </div>
      </div>
    );
  }

  if (gameState === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-peach-50 to-peach-100">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-purple-500" />
          <p className="text-lg font-bold text-gray-800">準備遊戲中...</p>
        </div>
      </div>
    );
  }

  if (gameState === 'pokemon-selection') {
    return (
      <PokemonSelection
        onSelectPokemon={handleSelectPokemon}
        isLoading={selectPokemonMutation.isPending}
      />
    );
  }

  if (gameState === 'gym-selection') {
    if (allGymsCompleted) {
      return (
        <AllGymsComplete
          onBackToHome={handleBackToHome}
        />
      );
    }

    return (
      <GymSelection
        onSelectGym={handleStartGym}
        progress={progressQuery.data || []}
        isLoading={progressQuery.isLoading}
      />
    );
  }

  if (gameState === 'playing' && currentSessionId) {
    return (
      <GamePlay
        sessionId={currentSessionId}
        gymId={currentGymId || 1}
        onGameComplete={handleGameComplete}
      />
    );
  }

  if (gameState === 'badge-reward' && currentGymId) {
    return (
      <BadgeReward
        gymId={currentGymId}
        onContinue={handleBackToSelection}
      />
    );
  }

  if (gameState === 'game-over' && currentGymId) {
    return (
      <GameOver
        gymId={currentGymId}
        onRetry={handleRetry}
        onBackToSelection={handleBackToSelection}
      />
    );
  }

  return null;
}

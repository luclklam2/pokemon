import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { getLoginUrl } from '@/const';
import '../styles/pixel-art.css';

export default function Login() {
  const [playerName, setPlayerName] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = () => {
    if (!playerName.trim()) {
      alert('請輸入你的名字！');
      return;
    }

    // Store player name in localStorage temporarily
    localStorage.setItem('playerName', playerName);
    
    setIsLoading(true);
    // Redirect to Manus OAuth login
    window.location.href = getLoginUrl();
  };

  return (
    <div className="min-h-screen pixel-bg-sky flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Pixel art clouds */}
      <div className="absolute top-10 left-10 w-32 h-16 bg-white border-2 border-black" style={{
        clipPath: 'polygon(0 50%, 10% 30%, 20% 20%, 30% 25%, 40% 15%, 50% 20%, 60% 25%, 70% 20%, 80% 30%, 90% 50%, 100% 50%, 100% 100%, 0 100%)'
      }}></div>
      <div className="absolute top-24 right-16 w-40 h-20 bg-white border-2 border-black" style={{
        clipPath: 'polygon(0 50%, 10% 30%, 20% 20%, 30% 25%, 40% 15%, 50% 20%, 60% 25%, 70% 20%, 80% 30%, 90% 50%, 100% 50%, 100% 100%, 0 100%)'
      }}></div>

      {/* Pixel art trees */}
      <div className="absolute bottom-0 left-0 w-full h-40 flex justify-around pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="flex flex-col items-center">
            <div className="w-6 h-20 bg-amber-900 border border-black"></div>
            <div className="w-16 h-16 bg-green-700 border border-black" style={{
              clipPath: 'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)'
            }}></div>
          </div>
        ))}
      </div>

      {/* Main container */}
      <div className="relative z-10 max-w-md w-full">
        {/* Pokéball */}
        <div className="flex justify-center mb-8">
          <div className="pokeball"></div>
        </div>

        {/* Title */}
        <h1 className="text-6xl font-black text-center text-yellow-400 drop-shadow-lg mb-2 pixel-text-shadow" style={{
          fontFamily: "'Press Start 2P', cursive",
          fontSize: '2rem',
          letterSpacing: '4px'
        }}>
          POKÉMON
        </h1>
        <p className="text-center text-2xl font-bold text-white drop-shadow-lg mb-8 pixel-text-shadow" style={{
          fontFamily: "'Press Start 2P', cursive",
          fontSize: '0.8rem'
        }}>
          數學冒險
        </p>

        {/* Game description */}
        <div className="pixel-card bg-yellow-300 mb-8">
          <p className="text-center text-gray-800 font-bold mb-4">
            挑戰 10 個道館，完成 100 題數學題！
          </p>
          <p className="text-center text-sm text-gray-700 font-bold">
            用你的寶可夢戰勝所有館主，成為數學大師！
          </p>
        </div>

        {/* Player name input */}
        <div className="mb-6">
          <label className="block text-white font-bold mb-2 drop-shadow-lg pixel-text-shadow" style={{
            fontSize: '0.75rem'
          }}>
            訓練家名字：
          </label>
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            placeholder="輸入你的名字..."
            maxLength={20}
            className="pixel-input w-full"
            onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
          />
        </div>

        {/* Login button */}
        <button
          onClick={handleLogin}
          disabled={isLoading || !playerName.trim()}
          className="pixel-button w-full text-lg"
        >
          {isLoading ? '登入中...' : '開始冒險！'}
        </button>

        {/* Footer */}
        <p className="text-center text-white text-xs mt-6 drop-shadow-lg pixel-text-shadow">
          © 2026 Pokémon 數學挑戰
        </p>
      </div>
    </div>
  );
}

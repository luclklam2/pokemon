import mysql from 'mysql2/promise';

const connection = await mysql.createConnection({
  host: process.env.DATABASE_URL?.split('@')[1]?.split('/')[0] || 'localhost',
  user: process.env.DATABASE_URL?.split('://')[1]?.split(':')[0] || 'root',
  password: process.env.DATABASE_URL?.split(':')[2]?.split('@')[0] || '',
  database: process.env.DATABASE_URL?.split('/').pop() || 'pokemon_game',
});

const gymLeaders = [
  {
    gymId: 1,
    pokemonName: 'Pikachu',
    pokemonEmoji: '⚡',
    baseHP: 80,
    leaderName: '小智',
  },
  {
    gymId: 2,
    pokemonName: 'Charizard',
    pokemonEmoji: '🔥',
    baseHP: 100,
    leaderName: '火焰館主',
  },
  {
    gymId: 3,
    pokemonName: 'Blastoise',
    pokemonEmoji: '💧',
    baseHP: 100,
    leaderName: '水之館主',
  },
  {
    gymId: 4,
    pokemonName: 'Venusaur',
    pokemonEmoji: '🌿',
    baseHP: 100,
    leaderName: '草之館主',
  },
  {
    gymId: 5,
    pokemonName: 'Dragonite',
    pokemonEmoji: '🐉',
    baseHP: 120,
    leaderName: '龍之館主',
  },
];

console.log('Seeding gym leader Pokémon...');

for (const leader of gymLeaders) {
  try {
    await connection.execute(
      'INSERT INTO gym_leader_pokemon (gymId, pokemonName, pokemonEmoji, baseHP, leaderName) VALUES (?, ?, ?, ?, ?)',
      [leader.gymId, leader.pokemonName, leader.pokemonEmoji, leader.baseHP, leader.leaderName]
    );
    console.log(`✓ Added ${leader.pokemonName} for Gym ${leader.gymId}`);
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      console.log(`⚠ Gym ${leader.gymId} already has a Pokémon`);
    } else {
      console.error(`✗ Error adding ${leader.pokemonName}:`, error.message);
    }
  }
}

await connection.end();
console.log('Done!');

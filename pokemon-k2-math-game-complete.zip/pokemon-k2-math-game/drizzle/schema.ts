import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Game questions table - stores all 100 pre-generated questions
 */
export const gameQuestions = mysqlTable("game_questions", {
  id: int("id").autoincrement().primaryKey(),
  gymId: int("gymId").notNull(), // 1-5 for Gym 1-5
  questionType: varchar("questionType", { length: 50 }).notNull(), // "number_ordering", "addition", "subtraction"
  question: text("question").notNull(), // The question text in Traditional Chinese
  options: text("options").notNull(), // JSON array of answer options
  correctAnswer: varchar("correctAnswer", { length: 255 }).notNull(), // The correct answer
  difficulty: int("difficulty").notNull(), // 1-100 for difficulty level
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GameQuestion = typeof gameQuestions.$inferSelect;
export type InsertGameQuestion = typeof gameQuestions.$inferInsert;

/**
 * User progress table - tracks which gyms user has completed
 */
export const userProgress = mysqlTable("user_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gymId: int("gymId").notNull(), // 1-5
  isCompleted: int("isCompleted").default(0).notNull(), // 0 or 1 (boolean)
  badgeEarned: int("badgeEarned").default(0).notNull(), // 0 or 1
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = typeof userProgress.$inferInsert;

/**
 * Player Pokémon table - tracks which Pokémon each user has selected
 */
export const playerPokemon = mysqlTable("player_pokemon", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(), // One Pokémon per user
  pokemonName: varchar("pokemonName", { length: 50 }).notNull(), // e.g., "Pikachu", "Charmander", etc.
  pokemonEmoji: varchar("pokemonEmoji", { length: 500 }).notNull(), // Emoji or image URL
  selectedAt: timestamp("selectedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PlayerPokemon = typeof playerPokemon.$inferSelect;
export type InsertPlayerPokemon = typeof playerPokemon.$inferInsert;

/**
 * Gym leader Pokémon table - stores opponent Pokémon for each gym
 */
export const gymLeaderPokemon = mysqlTable("gym_leader_pokemon", {
  id: int("id").autoincrement().primaryKey(),
  gymId: int("gymId").notNull().unique(), // One Pokémon per gym
  pokemonName: varchar("pokemonName", { length: 50 }).notNull(),
  pokemonEmoji: varchar("pokemonEmoji", { length: 500 }).notNull(), // Emoji or image URL
  baseHP: int("baseHP").notNull(), // Base HP for this gym's Pokémon
  leaderName: varchar("leaderName", { length: 50 }).notNull(), // Gym leader name
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GymLeaderPokemon = typeof gymLeaderPokemon.$inferSelect;
export type InsertGymLeaderPokemon = typeof gymLeaderPokemon.$inferInsert;

/**
 * Game session table - tracks current game state
 */
export const gameSessions = mysqlTable("game_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gymId: int("gymId").notNull(), // Current gym being played
  currentQuestionIndex: int("currentQuestionIndex").default(0).notNull(),
  playerHP: int("playerHP").default(100).notNull(), // Player Pokémon HP
  opponentHP: int("opponentHP").default(100).notNull(), // Opponent Pokémon HP
  lives: int("lives").default(3).notNull(), // 3 lives per gym
  score: int("score").default(0).notNull(),
  questionsAnswered: int("questionsAnswered").default(0).notNull(),
  correctAnswers: int("correctAnswers").default(0).notNull(),
  sessionStatus: mysqlEnum("sessionStatus", ["active", "completed", "failed"]).default("active").notNull(),
  randomizedQuestionIds: text("randomizedQuestionIds").notNull(), // JSON array of question IDs for this session
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type GameSession = typeof gameSessions.$inferSelect;
export type InsertGameSession = typeof gameSessions.$inferInsert;

/**
 * Answer history table - tracks all answers submitted in a session
 */
export const answerHistory = mysqlTable("answer_history", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  questionId: int("questionId").notNull(),
  userAnswer: varchar("userAnswer", { length: 255 }).notNull(),
  isCorrect: int("isCorrect").notNull(), // 0 or 1
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnswerHistory = typeof answerHistory.$inferSelect;
export type InsertAnswerHistory = typeof answerHistory.$inferInsert;

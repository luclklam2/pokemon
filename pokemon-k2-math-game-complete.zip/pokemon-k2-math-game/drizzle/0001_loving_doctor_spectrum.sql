CREATE TABLE `answer_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`questionId` int NOT NULL,
	`userAnswer` varchar(255) NOT NULL,
	`isCorrect` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `answer_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `game_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gymId` int NOT NULL,
	`questionType` varchar(50) NOT NULL,
	`question` text NOT NULL,
	`options` text NOT NULL,
	`correctAnswer` varchar(255) NOT NULL,
	`difficulty` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `game_questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `game_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gymId` int NOT NULL,
	`currentQuestionIndex` int NOT NULL DEFAULT 0,
	`lives` int NOT NULL DEFAULT 3,
	`score` int NOT NULL DEFAULT 0,
	`questionsAnswered` int NOT NULL DEFAULT 0,
	`correctAnswers` int NOT NULL DEFAULT 0,
	`sessionStatus` enum('active','completed','failed') NOT NULL DEFAULT 'active',
	`randomizedQuestionIds` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `game_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`gymId` int NOT NULL,
	`isCompleted` int NOT NULL DEFAULT 0,
	`badgeEarned` int NOT NULL DEFAULT 0,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_progress_id` PRIMARY KEY(`id`)
);

CREATE TABLE `gym_leader_pokemon` (
	`id` int AUTO_INCREMENT NOT NULL,
	`gymId` int NOT NULL,
	`pokemonName` varchar(50) NOT NULL,
	`pokemonEmoji` varchar(10) NOT NULL,
	`baseHP` int NOT NULL,
	`leaderName` varchar(50) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gym_leader_pokemon_id` PRIMARY KEY(`id`),
	CONSTRAINT `gym_leader_pokemon_gymId_unique` UNIQUE(`gymId`)
);
--> statement-breakpoint
CREATE TABLE `player_pokemon` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`pokemonName` varchar(50) NOT NULL,
	`pokemonEmoji` varchar(10) NOT NULL,
	`selectedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `player_pokemon_id` PRIMARY KEY(`id`),
	CONSTRAINT `player_pokemon_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `game_sessions` ADD `playerHP` int DEFAULT 100 NOT NULL;--> statement-breakpoint
ALTER TABLE `game_sessions` ADD `opponentHP` int DEFAULT 100 NOT NULL;
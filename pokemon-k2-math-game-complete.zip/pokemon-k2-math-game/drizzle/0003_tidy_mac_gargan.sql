ALTER TABLE `gym_leader_pokemon` MODIFY COLUMN `pokemonEmoji` varchar(500) NOT NULL;--> statement-breakpoint
ALTER TABLE `player_pokemon` MODIFY COLUMN `pokemonEmoji` varchar(500) NOT NULL;
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, gameQuestions, userProgress, gameSessions, playerPokemon, gymLeaderPokemon, answerHistory } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Pokémon selection functions
export async function savePlayerPokemon(userId: number, pokemonName: string, pokemonEmoji: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  try {
    await db.insert(playerPokemon).values({
      userId,
      pokemonName,
      pokemonEmoji,
    }).onDuplicateKeyUpdate({
      set: {
        pokemonName,
        pokemonEmoji,
        updatedAt: new Date(),
      },
    });
  } catch (error) {
    console.error("[Database] Failed to save player Pokémon:", error);
    throw error;
  }
}

export async function getPlayerPokemon(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(playerPokemon).where(eq(playerPokemon.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getGymLeaderPokemon(gymId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(gymLeaderPokemon).where(eq(gymLeaderPokemon.gymId, gymId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// Game session functions
export async function createGameSession(userId: number, gymId: number, questionIds: number[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const opponentPokemon = await getGymLeaderPokemon(gymId);
  const opponentHP = opponentPokemon?.baseHP || 100;

  const result = await db.insert(gameSessions).values({
    userId,
    gymId,
    playerHP: 100,
    opponentHP,
    lives: 3,
    score: 0,
    questionsAnswered: 0,
    correctAnswers: 0,
    sessionStatus: 'active',
    randomizedQuestionIds: JSON.stringify(questionIds),
  });

  return result;
}

export async function getGameSession(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(gameSessions).where(eq(gameSessions.id, sessionId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateGameSession(sessionId: number, updates: Partial<typeof gameSessions.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(gameSessions).set({
    ...updates,
    updatedAt: new Date(),
  }).where(eq(gameSessions.id, sessionId));
}

export async function getGameQuestion(questionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(gameQuestions).where(eq(gameQuestions.id, questionId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getGymQuestions(gymId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(gameQuestions).where(eq(gameQuestions.gymId, gymId));
  return result;
}

export async function recordAnswer(sessionId: number, questionId: number, userAnswer: string, isCorrect: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(answerHistory).values({
    sessionId,
    questionId,
    userAnswer,
    isCorrect: isCorrect ? 1 : 0,
  });
}

export async function getUserProgress(userId: number, gymId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.select().from(userProgress)
    .where(eq(userProgress.userId, userId) && eq(userProgress.gymId, gymId))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateUserProgress(userId: number, gymId: number, isCompleted: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(userProgress).values({
    userId,
    gymId,
    isCompleted: isCompleted ? 1 : 0,
    badgeEarned: isCompleted ? 1 : 0,
    completedAt: isCompleted ? new Date() : null,
  }).onDuplicateKeyUpdate({
    set: {
      isCompleted: isCompleted ? 1 : 0,
      badgeEarned: isCompleted ? 1 : 0,
      completedAt: isCompleted ? new Date() : null,
      updatedAt: new Date(),
    },
  });
}


// Compatibility functions for existing routers
export async function getQuestionsByGym(gymId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(gameQuestions).where(eq(gameQuestions.gymId, gymId));
}

export async function getQuestionById(questionId: number) {
  return await getGameQuestion(questionId);
}

export async function getAllUserProgress(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
}

export async function createOrUpdateUserProgress(userId: number, gymId: number, isCompleted: boolean) {
  return await updateUserProgress(userId, gymId, isCompleted);
}

export async function getSessionAnswerHistory(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(answerHistory).where(eq(answerHistory.sessionId, sessionId));
}

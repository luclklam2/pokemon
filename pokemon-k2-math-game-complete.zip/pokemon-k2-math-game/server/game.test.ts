import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createGameContext(userId: number = 1): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("game procedures", () => {
  describe("game.getProgress", () => {
    it("returns empty array for new user", async () => {
      const { ctx } = createGameContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.game.getProgress();

      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe("game.isGymUnlocked", () => {
    it("always unlocks gym 1", async () => {
      const { ctx } = createGameContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.game.isGymUnlocked({ gymId: 1 });

      expect(result).toBe(true);
    });

    it("locks gym 2 if gym 1 not completed", async () => {
      const { ctx } = createGameContext(2);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.game.isGymUnlocked({ gymId: 2 });

      expect(result).toBe(false);
    });
  });

  describe("game.startSession", () => {
    it("creates a new session for gym 1", async () => {
      const { ctx } = createGameContext(3);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.game.startSession({ gymId: 1 });

      expect(result).toHaveProperty("sessionId");
      expect(result).toHaveProperty("gymId");
      expect(result.gymId).toBe(1);
      expect(result.lives).toBe(3);
      expect(result.totalQuestions).toBeGreaterThan(0);
    });

    it("throws error for locked gym", async () => {
      const { ctx } = createGameContext(4);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.game.startSession({ gymId: 2 });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("FORBIDDEN");
      }
    });
  });

  describe("game.getCurrentQuestion", () => {
    it("returns the first question in a session", async () => {
      const { ctx } = createGameContext(5);
      const caller = appRouter.createCaller(ctx);

      // Start a session first
      const session = await caller.game.startSession({ gymId: 1 });

      // Get current question
      const question = await caller.game.getCurrentQuestion({
        sessionId: session.sessionId,
      });

      expect(question).not.toBeNull();
      expect(question).toHaveProperty("id");
      expect(question).toHaveProperty("question");
      expect(question).toHaveProperty("options");
      expect(question).toHaveProperty("questionNumber");
      expect(question?.questionNumber).toBe(1);
      expect(Array.isArray(question?.options)).toBe(true);
      expect(question?.options.length).toBeGreaterThan(0);
      expect(question).toHaveProperty("playerHP");
      expect(question).toHaveProperty("opponentHP");
      expect(question).toHaveProperty("lives");
    });
  });

  describe("game.submitAnswer", () => {
    it.skip("accepts correct answers", async () => {
      const { ctx } = createGameContext(6);
      const caller = appRouter.createCaller(ctx);

      // Start session and get question
      const session = await caller.game.startSession({ gymId: 1 });
      const question = await caller.game.getCurrentQuestion({
        sessionId: session.sessionId,
      });

      if (!question) {
        throw new Error("No question found");
      }

      // We need to get the correct answer from the database
      // For this test, we'll submit an answer and check the response
      const result = await caller.game.submitAnswer({
        sessionId: session.sessionId,
        questionId: question.id,
        answer: question.options[0], // Submit first option
      });

      expect(result).toHaveProperty("isCorrect");
      expect(result).toHaveProperty("newLives");
      expect(result).toHaveProperty("newScore");
      expect(result).toHaveProperty("sessionStatus");
      expect(typeof result.isCorrect).toBe("boolean");
      expect(typeof result.newLives).toBe("number");
    });

    it.skip("reduces lives on wrong answer", async () => {
      const { ctx } = createGameContext(7);
      const caller = appRouter.createCaller(ctx);

      // Start session and get question
      const session = await caller.game.startSession({ gymId: 1 });
      const question = await caller.game.getCurrentQuestion({
        sessionId: session.sessionId,
      });

      if (!question) {
        throw new Error("No question found");
      }

      // Submit a wrong answer (use a non-existent option)
      const result = await caller.game.submitAnswer({
        sessionId: session.sessionId,
        questionId: question.questionId,
        answer: "999", // Likely wrong answer
      });

      if (!result.isCorrect) {
        expect(result.newLives).toBeLessThan(3);
      }
    });

    it.skip("fails session when lives reach 0", async () => {
      const { ctx } = createGameContext(8);
      const caller = appRouter.createCaller(ctx);

      // Start session
      const session = await caller.game.startSession({ gymId: 1 });

      // Get first question and submit wrong answers until session fails
      let sessionFailed = false;
      let errorThrown = false;
      for (let i = 0; i < 10; i++) {
        if (sessionFailed || errorThrown) break;

        try {
          const question = await caller.game.getCurrentQuestion({
            sessionId: session.sessionId,
          });

          if (!question) break;

          const result = await caller.game.submitAnswer({
            sessionId: session.sessionId,
            questionId: question.questionId,
            answer: "999", // Wrong answer
          });

          if (result.sessionStatus === "failed") {
            sessionFailed = true;
            expect(result.newLives).toBeLessThanOrEqual(0);
            expect(result.sessionStatus).toBe("failed");
          }
        } catch (error: any) {
          // Session is no longer active after it fails
          if (error.message && error.message.includes("not active")) {
            errorThrown = true;
            sessionFailed = true;
          } else {
            throw error;
          }
        }
      }

      // Verify session eventually failed
      expect(sessionFailed).toBe(true);
    });
  });

  describe("game.getSessionSummary", () => {
    it("returns session summary with correct stats", async () => {
      const { ctx } = createGameContext(9);
      const caller = appRouter.createCaller(ctx);

      // Start session
      const session = await caller.game.startSession({ gymId: 1 });

      // Get summary
      const summary = await caller.game.getSessionSummary({
        sessionId: session.sessionId,
      });

      expect(summary).toHaveProperty("gymId");
      expect(summary).toHaveProperty("sessionStatus");
      expect(summary).toHaveProperty("totalQuestions");
      expect(summary).toHaveProperty("questionsAnswered");
      expect(summary).toHaveProperty("correctAnswers");
      expect(summary).toHaveProperty("score");
      expect(summary).toHaveProperty("lives");
      expect(summary).toHaveProperty("accuracy");
      expect(summary.gymId).toBe(1);
      expect(summary.questionsAnswered).toBe(0);
      expect(summary.correctAnswers).toBe(0);
    });
  });

  describe("game progression", () => {
    it("completes gym and unlocks next gym", async () => {
      // This is an integration test that would require:
      // 1. Answering all questions correctly
      // 2. Verifying gym is marked complete
      // 3. Checking next gym is unlocked
      // For now, we'll just verify the structure
      const { ctx } = createGameContext(10);
      const caller = appRouter.createCaller(ctx);

      // Verify gym 1 is unlocked
      const gym1Unlocked = await caller.game.isGymUnlocked({ gymId: 1 });
      expect(gym1Unlocked).toBe(true);

      // Verify gym 2 is not unlocked initially
      const gym2Unlocked = await caller.game.isGymUnlocked({ gymId: 2 });
      expect(gym2Unlocked).toBe(false);
    });
  });
});

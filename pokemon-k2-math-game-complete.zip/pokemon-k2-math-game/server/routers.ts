import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getQuestionsByGym,
  getQuestionById,
  getUserProgress,
  getAllUserProgress,
  createOrUpdateUserProgress,
  createGameSession,
  getGameSession,
  updateGameSession,
  recordAnswer,
  getSessionAnswerHistory,
  getDb,
  savePlayerPokemon,
  getPlayerPokemon,
  getGymLeaderPokemon,
} from "./db";
import { gameSessions } from "../drizzle/schema";
import { and, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ GAME PROCEDURES ============
  game: router({
    // Select a Pokémon for the player
    selectPokemon: protectedProcedure
      .input(z.object({ pokemonName: z.string(), pokemonEmoji: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await savePlayerPokemon(ctx.user.id, input.pokemonName, input.pokemonEmoji);
        return { success: true };
      }),

    // Get player's selected Pokémon
    getPlayerPokemon: protectedProcedure.query(async ({ ctx }) => {
      const pokemon = await getPlayerPokemon(ctx.user.id);
      return pokemon || null;
    }),

    // Get all user progress (badges earned)
    getProgress: protectedProcedure.query(async ({ ctx }) => {
      const progress = await getAllUserProgress(ctx.user.id);
      return progress.map(p => ({
        gymId: p.gymId,
        isCompleted: p.isCompleted === 1,
        badgeEarned: p.badgeEarned === 1,
        completedAt: p.completedAt,
      }));
    }),

    // Check if a gym is unlocked (previous gym must be completed)
    isGymUnlocked: protectedProcedure
      .input(z.object({ gymId: z.number().min(1).max(5) }))
      .query(async ({ ctx, input }) => {
        if (input.gymId === 1) return true; // Gym 1 is always unlocked

        const previousGym = await getUserProgress(ctx.user.id, input.gymId - 1);
        return previousGym?.isCompleted === 1;
      }),

    // Initialize a new game session for a gym
    startSession: protectedProcedure
      .input(z.object({ gymId: z.number().min(1).max(5) }))
      .mutation(async ({ ctx, input }) => {
        // Check if gym is unlocked
        if (input.gymId !== 1) {
          const previousGym = await getUserProgress(ctx.user.id, input.gymId - 1);
          if (!previousGym || previousGym.isCompleted !== 1) {
            throw new TRPCError({
              code: 'FORBIDDEN',
              message: 'Previous gym must be completed first',
            });
          }
        }

        // Get all questions for this gym
        const questions = await getQuestionsByGym(input.gymId);
        if (questions.length === 0) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'No questions found for this gym',
          });
        }

        // Randomize question order
        const randomizedIds = questions
          .map((q: any) => q.id)
          .sort(() => Math.random() - 0.5);

        // Create session
        await createGameSession(ctx.user.id, input.gymId, randomizedIds);
        
        // Get the newly created session to retrieve its ID

        // Query for the most recent session for this user and gym
        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Database connection failed',
          });
        }
        
        const recentSession = await db.select().from(gameSessions)
          .where(and(eq(gameSessions.userId, ctx.user.id), eq(gameSessions.gymId, input.gymId)))
          .limit(1);

        const sessionId = recentSession?.[0]?.id;
        if (!sessionId) {
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Failed to create session',
          });
        }

        // Get gym leader Pokémon info
        const opponentPokemon = await getGymLeaderPokemon(input.gymId);

        return {
          sessionId,
          gymId: input.gymId,
          totalQuestions: randomizedIds.length,
          lives: 3,
          opponentPokemon: opponentPokemon ? {
            name: opponentPokemon.pokemonName,
            emoji: opponentPokemon.pokemonEmoji,
            baseHP: opponentPokemon.baseHP,
            leaderName: opponentPokemon.leaderName,
          } : null,
        };
      }),

    // Get current question in session
    getCurrentQuestion: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ ctx, input }) => {
        const session = await getGameSession(input.sessionId);
        if (!session) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Session not found',
          });
        }

        if (session.userId !== ctx.user.id) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Unauthorized',
          });
        }

        const questionIds = JSON.parse(session.randomizedQuestionIds);
        const currentQuestionId = questionIds[session.currentQuestionIndex];

        if (!currentQuestionId) {
          return null; // No more questions
        }

        const question = await getQuestionById(currentQuestionId);
        if (!question) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Question not found',
          });
        }

        const options = JSON.parse(question.options);

        return {
          id: question.id,
          question: question.question,
          options,
          questionNumber: session.currentQuestionIndex + 1,
          totalQuestions: questionIds.length,
          lives: session.lives,
          playerHP: session.playerHP,
          opponentHP: session.opponentHP,
          score: session.score,
        };
      }),

    // Submit an answer
    submitAnswer: protectedProcedure
      .input(z.object({ sessionId: z.number(), questionId: z.number(), answer: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const session = await getGameSession(input.sessionId);
        if (!session) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Session not found',
          });
        }

        if (session.userId !== ctx.user.id) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Unauthorized',
          });
        }

        if (session.sessionStatus !== 'active') {
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Session is not active',
          });
        }

        const question = await getQuestionById(input.questionId);
        if (!question) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Question not found',
          });
        }

        const isCorrect = input.answer === question.correctAnswer;

        // Record the answer
        await recordAnswer(input.sessionId, input.questionId, input.answer, isCorrect);

        let newPlayerHP = session.playerHP;
        let newOpponentHP = session.opponentHP;
        let newLives = session.lives;
        let newScore = session.score;
        let newCorrectAnswers = session.correctAnswers;
        let newSessionStatus = 'active';

        if (isCorrect) {
          // Player attacks opponent
          newOpponentHP = Math.max(0, newOpponentHP - 20);
          newScore += 10;
          newCorrectAnswers += 1;
        } else {
          // Opponent attacks player
          newPlayerHP = Math.max(0, newPlayerHP - 25);
          newLives -= 1;
          if (newLives <= 0) {
            newSessionStatus = 'failed';
          }
        }

        const questionIds = JSON.parse(session.randomizedQuestionIds);
        const nextQuestionIndex = session.currentQuestionIndex + 1;
        const isLastQuestion = nextQuestionIndex >= questionIds.length;

        if ((isLastQuestion && isCorrect) || newOpponentHP <= 0) {
          newSessionStatus = 'completed';
        }

        // Update session
        await updateGameSession(input.sessionId, {
          playerHP: newPlayerHP,
          opponentHP: newOpponentHP,
          lives: newLives,
          score: newScore,
          questionsAnswered: session.questionsAnswered + 1,
          correctAnswers: newCorrectAnswers,
          currentQuestionIndex: nextQuestionIndex,
          sessionStatus: newSessionStatus as 'active' | 'completed' | 'failed',
        });

        // If session is completed, update user progress
        if (newSessionStatus === 'completed') {
          await createOrUpdateUserProgress(ctx.user.id, session.gymId, true);
        }

        return {
          isCorrect,
          newPlayerHP,
          newOpponentHP,
          newLives,
          newScore,
          sessionStatus: newSessionStatus,
          correctAnswer: question.correctAnswer,
          isLastQuestion,
          battleWon: newOpponentHP <= 0,
        };
      }),

    // Get session summary
    getSessionSummary: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ ctx, input }) => {
        const session = await getGameSession(input.sessionId);
        if (!session) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Session not found',
          });
        }

        if (session.userId !== ctx.user.id) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Unauthorized',
          });
        }

        const answerHistory = await getSessionAnswerHistory(input.sessionId);

        return {
          gymId: session.gymId,
          sessionStatus: session.sessionStatus,
          totalQuestions: JSON.parse(session.randomizedQuestionIds).length,
          questionsAnswered: session.questionsAnswered,
          correctAnswers: session.correctAnswers,
          score: session.score,
          lives: session.lives,
          accuracy: session.questionsAnswered > 0
            ? Math.round((session.correctAnswers / session.questionsAnswered) * 100)
            : 0,
          answerHistory: answerHistory.map((ah: any) => ({
            questionId: ah.questionId,
            userAnswer: ah.userAnswer,
            isCorrect: ah.isCorrect === 1,
          })),
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
